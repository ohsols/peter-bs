import { createContext, useContext, useState, useEffect, useCallback } from "react";
import { base44 } from "@/api/base44Client";
import { useProfile } from "./useProfile";

const WatchTrackingContext = createContext(null);

export function WatchTrackingProvider({ children }) {
  const { activeProfile } = useProfile();
  const [continueWatching, setContinueWatching] = useState([]);
  const [watchHistory, setWatchHistory] = useState([]);

  useEffect(() => {
    if (!activeProfile?.id) {
      setContinueWatching([]);
      setWatchHistory([]);
      return;
    }
    loadData();
  }, [activeProfile?.id]);

  const loadData = async () => {
    if (!activeProfile?.id) return;
    const [cw, wh] = await Promise.all([
      base44.entities.ContinueWatching.filter({ profile_id: activeProfile.id }, "-last_watched", 50),
      base44.entities.WatchHistory.filter({ profile_id: activeProfile.id }, "-watched_at", 100)
    ]);
    setContinueWatching(cw);
    setWatchHistory(wh);
  };

  // Call this when user starts/resumes watching something
  const markWatching = useCallback(async (item) => {
    if (!activeProfile?.id || !activeProfile?.user_email) return;
    // item: { id, item_type, title, poster_url, episode_id?, episode_title?, season_number?, episode_number? }
    const existing = continueWatching.find(
      (c) => c.item_id === item.id && (item.episode_id ? c.episode_id === item.episode_id : true)
    );
    const payload = {
      profile_id: activeProfile.id,
      user_email: activeProfile.user_email,
      item_id: item.id,
      item_type: item.item_type,
      item_title: item.title,
      item_poster: item.poster_url || "",
      episode_id: item.episode_id || "",
      episode_title: item.episode_title || "",
      season_number: item.season_number || null,
      episode_number: item.episode_number || null,
      last_watched: new Date().toISOString(),
      timestamp_seconds: item.timestamp_seconds || 0,
    };
    if (existing) {
      const updated = await base44.entities.ContinueWatching.update(existing.id, payload);
      setContinueWatching((prev) => prev.map((c) => c.id === existing.id ? updated : c));
    } else {
      const created = await base44.entities.ContinueWatching.create(payload);
      setContinueWatching((prev) => [created, ...prev]);
    }
  }, [activeProfile, continueWatching]);

  // Call this when user finishes (marks complete)
  const markWatched = useCallback(async (item) => {
    if (!activeProfile?.id || !activeProfile?.user_email) return;
    // Add to history
    const histPayload = {
      profile_id: activeProfile.id,
      user_email: activeProfile.user_email,
      item_id: item.id,
      item_type: item.item_type,
      item_title: item.title,
      item_poster: item.poster_url || "",
      episode_id: item.episode_id || "",
      episode_title: item.episode_title || "",
      season_number: item.season_number || null,
      episode_number: item.episode_number || null,
      watched_at: new Date().toISOString(),
    };
    const created = await base44.entities.WatchHistory.create(histPayload);
    setWatchHistory((prev) => [created, ...prev]);

    // Remove from continue watching
    const existing = continueWatching.find(
      (c) => c.item_id === item.id && (item.episode_id ? c.episode_id === item.episode_id : !c.episode_id)
    );
    if (existing) {
      await base44.entities.ContinueWatching.delete(existing.id);
      setContinueWatching((prev) => prev.filter((c) => c.id !== existing.id));
    }
  }, [activeProfile, continueWatching]);

  const removeContinueWatching = useCallback(async (id) => {
    await base44.entities.ContinueWatching.delete(id);
    setContinueWatching((prev) => prev.filter((c) => c.id !== id));
  }, []);

  const removeHistory = useCallback(async (id) => {
    await base44.entities.WatchHistory.delete(id);
    setWatchHistory((prev) => prev.filter((h) => h.id !== id));
  }, []);

  const getTimestamp = useCallback((itemId, episodeId) => {
    const entry = continueWatching.find(
      (c) => c.item_id === itemId && (episodeId ? c.episode_id === episodeId : true)
    );
    return entry?.timestamp_seconds || 0;
  }, [continueWatching]);

  return (
    <WatchTrackingContext.Provider value={{
      continueWatching,
      watchHistory,
      markWatching,
      markWatched,
      removeContinueWatching,
      removeHistory,
      getTimestamp,
      reload: loadData
    }}>
      {children}
    </WatchTrackingContext.Provider>
  );
}

export function useWatchTracking() {
  const ctx = useContext(WatchTrackingContext);
  if (!ctx) return {
    continueWatching: [], watchHistory: [],
    markWatching: () => {}, markWatched: () => {},
    removeContinueWatching: () => {}, removeHistory: () => {},
    getTimestamp: () => 0, reload: () => {}
  };
  return ctx;
}