import { createContext, useContext, useState, useEffect } from "react";

const ProfileContext = createContext(null);

export function ProfileProvider({ children }) {
  const [activeProfile, setActiveProfile] = useState(() => {
    try {
      const stored = localStorage.getItem("activeProfile");
      return stored ? JSON.parse(stored) : null;
    } catch { return null; }
  });

  const selectProfile = (profile) => {
    setActiveProfile(profile);
    localStorage.setItem("activeProfile", JSON.stringify(profile));
  };

  const clearProfile = () => {
    setActiveProfile(null);
    localStorage.removeItem("activeProfile");
  };

  return (
    <ProfileContext.Provider value={{ activeProfile, selectProfile, clearProfile }}>
      {children}
    </ProfileContext.Provider>
  );
}

export function useProfile() {
  return useContext(ProfileContext);
}