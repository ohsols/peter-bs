import { createContext, useContext, useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useProfile } from "./useProfile";

const RatingsContext = createContext(null);

export function RatingsProvider({ children }) {
  const { activeProfile } = useProfile();
  const [ratings, setRatings] = useState([]);

  useEffect(() => {
    if (!activeProfile?.user_email) { setRatings([]); return; }
    base44.entities.Rating.filter({ user_email: activeProfile.user_email }).then(setRatings);
  }, [activeProfile?.user_email]);

  const getRating = (itemId) => ratings.find((r) => r.item_id === itemId)?.stars || 0;

  const setRating = async (item, stars) => {
    if (!activeProfile?.user_email) return;
    const existing = ratings.find((r) => r.item_id === item.id);
    if (existing) {
      const updated = await base44.entities.Rating.update(existing.id, { stars });
      setRatings((prev) => prev.map((r) => r.id === existing.id ? { ...r, stars } : r));
    } else {
      const created = await base44.entities.Rating.create({
        user_email: activeProfile.user_email,
        item_id: item.id,
        item_type: item.item_type,
        stars,
      });
      setRatings((prev) => [...prev, created]);
    }
  };

  return (
    <RatingsContext.Provider value={{ ratings, getRating, setRating }}>
      {children}
    </RatingsContext.Provider>
  );
}

export function useRatings() {
  return useContext(RatingsContext);
}