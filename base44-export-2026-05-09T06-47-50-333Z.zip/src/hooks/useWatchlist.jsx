import { useState, useEffect, useCallback, createContext, useContext, useRef } from "react";
import { base44 } from "@/api/base44Client";

const WatchlistContext = createContext(null);

export function WatchlistProvider({ children }) {
  const [watchlist, setWatchlist] = useState([]);
  const userRef = useRef(null);

  useEffect(() => {
    base44.auth.me().then((u) => {
      if (u) {
        userRef.current = u;
        loadWatchlist(u.email);
      }
    }).catch(() => {});
  }, []);

  const loadWatchlist = async (email) => {
    const items = await base44.entities.Watchlist.filter({ user_email: email });
    setWatchlist(items);
  };

  const isInWatchlist = useCallback((itemId) => {
    return watchlist.some((w) => w.item_id === itemId);
  }, [watchlist]);

  const toggle = useCallback(async (item) => {
    const user = userRef.current;
    if (!user) {
      // Try to get user one more time
      try {
        const u = await base44.auth.me();
        if (!u) return;
        userRef.current = u;
      } catch { return; }
    }
    const currentUser = userRef.current;
    const existing = watchlist.find((w) => w.item_id === item.id);
    if (existing) {
      await base44.entities.Watchlist.delete(existing.id);
      setWatchlist((prev) => prev.filter((w) => w.id !== existing.id));
    } else {
      const created = await base44.entities.Watchlist.create({
        user_email: currentUser.email,
        item_id: item.id,
        item_type: item.item_type,
        item_title: item.title,
        item_poster: item.poster_url || ""
      });
      setWatchlist((prev) => [...prev, created]);
    }
  }, [watchlist]);

  return (
    <WatchlistContext.Provider value={{ watchlist, isInWatchlist, toggle }}>
      {children}
    </WatchlistContext.Provider>
  );
}

export function useWatchlist() {
  return useContext(WatchlistContext);
}