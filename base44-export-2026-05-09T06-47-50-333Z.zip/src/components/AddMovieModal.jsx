import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Link2, Film, Loader2, Check, Upload, Tv, Plus, Trash2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "@/components/ui/use-toast";

const GENRES = ["Action", "Comedy", "Drama", "Horror", "Sci-Fi", "Thriller", "Romance", "Documentary", "Animation", "Fantasy", "Mystery", "Adventure", "Anime"];

const emptyEpisode = () => ({ title: "", drive_link: "", episode_number: "" });

export default function AddMovieModal({ open, onClose, onMovieAdded }) {
  const [mode, setMode] = useState("movie"); // "movie" | "tvshow"
  const [step, setStep] = useState(1);
  const [saving, setSaving] = useState(false);

  // Movie form
  const [form, setForm] = useState({
    title: "", description: "", genre: "", year: "",
    director: "", runtime: "", drive_link: "", poster_url: "", is_featured: false, cast: []
  });
  const [castInput, setCastInput] = useState("");
  const [linkValid, setLinkValid] = useState(null);

  // TV show manual entry
  const [showTitle, setShowTitle] = useState("");
  const [showGenre, setShowGenre] = useState("");
  const [showYear, setShowYear] = useState("");
  const [showPoster, setShowPoster] = useState("");
  const [showDescription, setShowDescription] = useState("");
  const [showCastInput, setShowCastInput] = useState("");
  const [selectedSeason, setSelectedSeason] = useState("1");
  const [seasons, setSeasons] = useState({ "1": [emptyEpisode()] }); // { "1": [...eps], "2": [...] }

  const validateLink = (link) => /drive\.google\.com|docs\.google\.com/.test(link) || link.startsWith("http");

  const handleLinkChange = (val) => {
    setForm({ ...form, drive_link: val });
    setLinkValid(val.length > 10 ? validateLink(val) : null);
  };

  const handlePosterUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    setForm({ ...form, poster_url: file_url });
  };

  const handleShowPosterUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    setShowPoster(file_url);
  };

  const handleSubmitMovie = async () => {
    if (!form.title || !form.drive_link) {
      toast({ title: "Required fields", description: "Title and Drive link are required", variant: "destructive" });
      return;
    }
    setSaving(true);
    const data = { ...form };
    if (data.year) data.year = parseInt(data.year); else delete data.year;
    if (!data.genre) delete data.genre;
    if (castInput.trim()) data.cast = castInput.split(",").map(s => s.trim()).filter(Boolean);
    else delete data.cast;
    await base44.entities.Movie.create(data);
    toast({ title: "Film archived", description: `"${form.title}" added to your collection.` });
    setSaving(false);
    handleClose();
    onMovieAdded?.();
  };

  // --- TV Show helpers ---
  const addSeason = () => {
    const next = String(Object.keys(seasons).length + 1);
    setSeasons((prev) => ({ ...prev, [next]: [emptyEpisode()] }));
    setSelectedSeason(next);
  };

  const removeSeason = (s) => {
    const updated = { ...seasons };
    delete updated[s];
    const keys = Object.keys(updated);
    setSeasons(updated);
    setSelectedSeason(keys[keys.length - 1] || "1");
  };

  const addEpisode = () => {
    setSeasons((prev) => ({
      ...prev,
      [selectedSeason]: [...(prev[selectedSeason] || []), emptyEpisode()]
    }));
  };

  const removeEpisode = (idx) => {
    setSeasons((prev) => ({
      ...prev,
      [selectedSeason]: prev[selectedSeason].filter((_, i) => i !== idx)
    }));
  };

  const updateEpisode = (idx, field, value) => {
    setSeasons((prev) => ({
      ...prev,
      [selectedSeason]: prev[selectedSeason].map((ep, i) => i === idx ? { ...ep, [field]: value } : ep)
    }));
  };

  const handleSaveShow = async () => {
    if (!showTitle.trim()) {
      toast({ title: "Show title required", variant: "destructive" });
      return;
    }
    setSaving(true);
    const showData = { title: showTitle.trim() };
    if (showGenre) showData.genre = showGenre;
    if (showYear) showData.year = parseInt(showYear);
    if (showPoster) showData.poster_url = showPoster;
    if (showDescription) showData.description = showDescription;
    if (showCastInput.trim()) showData.cast = showCastInput.split(",").map(s => s.trim()).filter(Boolean);

    const existing = await base44.entities.TvShow.filter({ title: showTitle.trim() });
    const show = existing.length > 0 ? existing[0] : await base44.entities.TvShow.create(showData);

    const allEpisodes = [];
    Object.entries(seasons).forEach(([seasonNum, eps]) => {
      eps.forEach((ep, i) => {
        if (ep.title || ep.drive_link) {
          allEpisodes.push({
            show_id: show.id,
            title: ep.title || `Episode ${i + 1}`,
            drive_link: ep.drive_link,
            season_number: parseInt(seasonNum),
            episode_number: ep.episode_number ? parseInt(ep.episode_number) : i + 1
          });
        }
      });
    });

    if (allEpisodes.length > 0) await base44.entities.Episode.bulkCreate(allEpisodes);
    toast({ title: "Show saved!", description: `"${showTitle}" — ${allEpisodes.length} episode(s) added.` });
    setSaving(false);
    handleClose();
    onMovieAdded?.();
  };

  const handleClose = () => {
    setStep(1);
    setMode("movie");
    setLinkValid(null);
    setCastInput("");
    setShowCastInput("");
    setForm({ title: "", description: "", genre: "", year: "", director: "", runtime: "", drive_link: "", poster_url: "", is_featured: false, cast: [] });
    setShowTitle(""); setShowGenre(""); setShowYear(""); setShowPoster(""); setShowDescription("");
    setSelectedSeason("1");
    setSeasons({ "1": [emptyEpisode()] });
    onClose();
  };

  const seasonKeys = Object.keys(seasons).sort((a, b) => parseInt(a) - parseInt(b));
  const currentEpisodes = seasons[selectedSeason] || [];

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[100] flex items-center justify-center bg-background/80 backdrop-blur-xl p-4"
          onClick={handleClose}
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
            className="w-full max-w-2xl bg-card border border-border rounded-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="flex items-center justify-between p-6 border-b border-border">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                  {mode === "movie" ? <Film className="w-5 h-5 text-primary" /> : <Tv className="w-5 h-5 text-primary" />}
                </div>
                <div>
                  <h2 className="text-lg font-bold">Add to Archive</h2>
                  <div className="flex items-center gap-3 mt-0.5">
                    <button onClick={() => setMode("movie")} className={`text-xs font-medium transition-colors ${mode === "movie" ? "text-primary" : "text-muted-foreground hover:text-foreground"}`}>
                      Movie
                    </button>
                    <span className="text-muted-foreground/40 text-xs">|</span>
                    <button onClick={() => { setMode("tvshow"); setStep(1); }} className={`text-xs font-medium transition-colors ${mode === "tvshow" ? "text-primary" : "text-muted-foreground hover:text-foreground"}`}>
                      TV Show
                    </button>
                  </div>
                </div>
              </div>
              <button onClick={handleClose} className="w-8 h-8 rounded-full hover:bg-secondary flex items-center justify-center transition-colors">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-6 space-y-5 max-h-[70vh] overflow-y-auto">
              {/* ===== MOVIE MODE ===== */}
              {mode === "movie" && (
                <>
                  {step === 1 && (
                    <>
                      <div>
                        <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-2 block">Google Drive Link *</label>
                        <div className="relative">
                          <Link2 className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                          <Input
                            value={form.drive_link}
                            onChange={(e) => handleLinkChange(e.target.value)}
                            placeholder="Paste your Google Drive link..."
                            className="pl-11 pr-11 h-12 bg-secondary border-border"
                          />
                          {linkValid !== null && (
                            <div className="absolute right-4 top-1/2 -translate-y-1/2">
                              {linkValid ? <Check className="w-4 h-4 text-primary" /> : <X className="w-4 h-4 text-destructive" />}
                            </div>
                          )}
                        </div>
                      </div>
                      <div>
                        <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-2 block">Film Title *</label>
                        <Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="Enter the film title" className="h-12 bg-secondary border-border" />
                      </div>
                      <button onClick={() => setStep(2)} disabled={!form.title || !form.drive_link} className="w-full py-3 bg-primary text-primary-foreground rounded-lg font-semibold disabled:opacity-30 disabled:cursor-not-allowed hover:bg-primary/90 transition-all">
                        Continue
                      </button>
                    </>
                  )}
                  {step === 2 && (
                    <>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-2 block">Genre</label>
                          <Select value={form.genre} onValueChange={(val) => setForm({ ...form, genre: val })}>
                            <SelectTrigger className="h-12 bg-secondary border-border"><SelectValue placeholder="Select genre" /></SelectTrigger>
                            <SelectContent>{GENRES.map((g) => <SelectItem key={g} value={g}>{g}</SelectItem>)}</SelectContent>
                          </Select>
                        </div>
                        <div>
                          <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-2 block">Year</label>
                          <Input value={form.year} onChange={(e) => setForm({ ...form, year: e.target.value })} placeholder="2024" type="number" className="h-12 bg-secondary border-border" />
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-2 block">Director</label>
                          <Input value={form.director} onChange={(e) => setForm({ ...form, director: e.target.value })} placeholder="Director name" className="h-12 bg-secondary border-border" />
                        </div>
                        <div>
                          <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-2 block">Runtime</label>
                          <Input value={form.runtime} onChange={(e) => setForm({ ...form, runtime: e.target.value })} placeholder="2h 15m" className="h-12 bg-secondary border-border" />
                        </div>
                      </div>
                      <div>
                        <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-2 block">Description</label>
                        <Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="Brief synopsis..." rows={3} className="bg-secondary border-border resize-none" />
                      </div>
                      <div>
                        <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-2 block">Poster Image</label>
                        {form.poster_url ? (
                          <div className="relative w-24 h-36 rounded-lg overflow-hidden">
                            <img src={form.poster_url} alt="Poster" className="w-full h-full object-cover" />
                            <button onClick={() => setForm({ ...form, poster_url: "" })} className="absolute top-1 right-1 w-5 h-5 rounded-full bg-background/80 flex items-center justify-center"><X className="w-3 h-3" /></button>
                          </div>
                        ) : (
                          <label className="flex items-center gap-3 px-4 py-3 bg-secondary border border-dashed border-border rounded-lg cursor-pointer hover:border-primary/50 transition-colors">
                            <Upload className="w-4 h-4 text-muted-foreground" />
                            <span className="text-sm text-muted-foreground">Upload poster image</span>
                            <input type="file" accept="image/*" className="hidden" onChange={handlePosterUpload} />
                          </label>
                        )}
                      </div>
                      <div>
                        <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-2 block">Cast (comma-separated)</label>
                        <Input value={castInput} onChange={(e) => setCastInput(e.target.value)} placeholder="e.g. Tom Hanks, Robin Wright" className="h-12 bg-secondary border-border" />
                      </div>
                      <label className="flex items-center gap-3 cursor-pointer">
                        <input type="checkbox" checked={form.is_featured} onChange={(e) => setForm({ ...form, is_featured: e.target.checked })} className="w-4 h-4 rounded accent-primary" />
                        <span className="text-sm text-muted-foreground">Feature on homepage</span>
                      </label>
                      <div className="flex gap-3">
                        <button onClick={() => setStep(1)} className="flex-1 py-3 bg-secondary text-foreground rounded-lg font-medium hover:bg-secondary/80 transition-all border border-border">Back</button>
                        <button onClick={handleSubmitMovie} disabled={saving} className="flex-1 py-3 bg-primary text-primary-foreground rounded-lg font-semibold disabled:opacity-50 hover:bg-primary/90 transition-all flex items-center justify-center gap-2">
                          {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <><Film className="w-4 h-4" />Archive Film</>}
                        </button>
                      </div>
                    </>
                  )}
                </>
              )}

              {/* ===== TV SHOW MODE ===== */}
              {mode === "tvshow" && (
                <div className="space-y-5">
                  {/* Show Info */}
                  <div className="grid grid-cols-2 gap-4">
                    <div className="col-span-2">
                      <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-2 block">Show Title *</label>
                      <Input value={showTitle} onChange={(e) => setShowTitle(e.target.value)} placeholder="e.g. Breaking Bad" className="h-12 bg-secondary border-border" />
                    </div>
                    <div>
                      <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-2 block">Genre</label>
                      <Select value={showGenre} onValueChange={setShowGenre}>
                        <SelectTrigger className="h-11 bg-secondary border-border"><SelectValue placeholder="Select genre" /></SelectTrigger>
                        <SelectContent>{GENRES.map((g) => <SelectItem key={g} value={g}>{g}</SelectItem>)}</SelectContent>
                      </Select>
                    </div>
                    <div>
                      <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-2 block">Year</label>
                      <Input value={showYear} onChange={(e) => setShowYear(e.target.value)} placeholder="2024" type="number" className="h-11 bg-secondary border-border" />
                    </div>
                    <div className="col-span-2">
                      <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-2 block">Description</label>
                      <Textarea value={showDescription} onChange={(e) => setShowDescription(e.target.value)} placeholder="Brief synopsis..." rows={2} className="bg-secondary border-border resize-none" />
                    </div>
                    <div className="col-span-2">
                      <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-2 block">Cast (comma-separated)</label>
                      <Input value={showCastInput} onChange={(e) => setShowCastInput(e.target.value)} placeholder="e.g. Bryan Cranston, Aaron Paul" className="h-11 bg-secondary border-border" />
                    </div>
                    <div className="col-span-2">
                      <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-2 block">Poster Image</label>
                      {showPoster ? (
                        <div className="relative w-20 h-30 rounded-lg overflow-hidden inline-block">
                          <img src={showPoster} alt="Poster" className="w-20 h-28 object-cover rounded-lg" />
                          <button onClick={() => setShowPoster("")} className="absolute top-1 right-1 w-5 h-5 rounded-full bg-background/80 flex items-center justify-center"><X className="w-3 h-3" /></button>
                        </div>
                      ) : (
                        <label className="flex items-center gap-3 px-4 py-3 bg-secondary border border-dashed border-border rounded-lg cursor-pointer hover:border-primary/50 transition-colors">
                          <Upload className="w-4 h-4 text-muted-foreground" />
                          <span className="text-sm text-muted-foreground">Upload poster</span>
                          <input type="file" accept="image/*" className="hidden" onChange={handleShowPosterUpload} />
                        </label>
                      )}
                    </div>
                  </div>

                  {/* Season selector */}
                  <div className="border-t border-border pt-4">
                    <div className="flex items-center justify-between mb-3">
                      <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Episodes</label>
                      <button onClick={addSeason} className="flex items-center gap-1 text-xs text-primary hover:underline">
                        <Plus className="w-3 h-3" /> Add Season
                      </button>
                    </div>

                    {/* Season dropdown */}
                    <div className="flex items-center gap-2 mb-4">
                      <Select value={selectedSeason} onValueChange={setSelectedSeason}>
                        <SelectTrigger className="h-10 bg-secondary border-border w-40">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {seasonKeys.map((s) => (
                            <SelectItem key={s} value={s}>Season {s}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      {seasonKeys.length > 1 && (
                        <button onClick={() => removeSeason(selectedSeason)} className="text-xs text-destructive hover:underline">Remove season</button>
                      )}
                    </div>

                    {/* Episodes for selected season */}
                    <div className="space-y-3">
                      {currentEpisodes.map((ep, idx) => (
                        <div key={idx} className="flex items-start gap-2 p-3 bg-secondary/50 rounded-lg border border-border">
                          <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 text-xs font-bold text-primary mt-1">
                            {idx + 1}
                          </div>
                          <div className="flex-1 space-y-2">
                            <Input
                              value={ep.title}
                              onChange={(e) => updateEpisode(idx, "title", e.target.value)}
                              placeholder={`Episode ${idx + 1} title`}
                              className="h-9 bg-secondary border-border text-sm"
                            />
                            <Input
                              value={ep.drive_link}
                              onChange={(e) => updateEpisode(idx, "drive_link", e.target.value)}
                              placeholder="Google Drive link"
                              className="h-9 bg-secondary border-border text-sm"
                            />
                          </div>
                          {currentEpisodes.length > 1 && (
                            <button onClick={() => removeEpisode(idx)} className="flex-shrink-0 w-7 h-7 rounded-full hover:bg-destructive/20 flex items-center justify-center text-muted-foreground hover:text-destructive transition-colors mt-1">
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      ))}
                      <button onClick={addEpisode} className="flex items-center gap-2 w-full py-2.5 rounded-lg border border-dashed border-border text-sm text-muted-foreground hover:border-primary/50 hover:text-primary transition-colors justify-center">
                        <Plus className="w-4 h-4" /> Add Episode
                      </button>
                    </div>
                  </div>

                  <button onClick={handleSaveShow} disabled={saving || !showTitle.trim()} className="w-full py-3 bg-primary text-primary-foreground rounded-lg font-semibold disabled:opacity-50 hover:bg-primary/90 transition-all flex items-center justify-center gap-2">
                    {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <><Tv className="w-4 h-4" />Save Show</>}
                  </button>
                </div>
              )}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}