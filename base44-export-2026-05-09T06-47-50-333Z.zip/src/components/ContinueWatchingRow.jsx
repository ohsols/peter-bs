import { Link } from "react-router-dom";
import { useWatchTracking } from "@/hooks/useWatchTracking";
import { useProfile } from "@/hooks/useProfile";
import { Play, X, Clock } from "lucide-react";
import { motion } from "framer-motion";
import { formatDistanceToNow } from "date-fns";

function ProgressBar({ timestamp, duration }) {
  if (!duration || !timestamp) return null;
  const pct = Math.min(100, Math.round((timestamp / duration) * 100));
  return (
    <div className="h-1 w-full bg-secondary rounded-full overflow-hidden mt-2">
      <div className="h-full bg-primary rounded-full" style={{ width: `${pct}%` }} />
    </div>
  );
}

export default function ContinueWatchingRow() {
  const { activeProfile } = useProfile();
  const { continueWatching, removeContinueWatching } = useWatchTracking();

  if (!activeProfile || continueWatching.length === 0) return null;

  return (
    <div className="px-6 md:px-12 py-3">
      <h2 className="text-base md:text-lg font-bold text-white mb-2">Continue Watching</h2>
      <div className="flex gap-4 overflow-x-auto pb-2" style={{ scrollbarWidth: "none" }}>
        {continueWatching.map((item, i) => {
          const href = item.item_type === "movie" ? `/movie/${item.item_id}` : `/show/${item.item_id}`;
          return (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.05 }}
              className="relative flex-shrink-0 w-[200px] group"
            >
              <Link to={href} className="block">
                <div className="relative aspect-[16/9] rounded-lg overflow-hidden bg-secondary">
                  {item.item_poster ? (
                    <img src={item.item_poster} alt={item.item_title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-2xl font-black text-muted-foreground/20">
                      {item.item_title?.charAt(0)}
                    </div>
                  )}
                  <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <div className="w-10 h-10 rounded-full bg-primary/90 flex items-center justify-center">
                      <Play className="w-4 h-4 fill-white text-white ml-0.5" />
                    </div>
                  </div>
                  {/* Progress bar */}
                  {item.timestamp_seconds > 0 && item.duration_seconds > 0 && (
                    <div className="absolute bottom-0 left-0 right-0 h-1 bg-black/40">
                      <div
                        className="h-full bg-primary"
                        style={{ width: `${Math.min(100, (item.timestamp_seconds / item.duration_seconds) * 100)}%` }}
                      />
                    </div>
                  )}
                </div>
                <div className="mt-2 px-0.5">
                  <p className="text-xs font-semibold truncate">{item.item_title}</p>
                  {item.episode_title && (
                    <p className="text-xs text-muted-foreground truncate">
                      S{item.season_number} E{item.episode_number} · {item.episode_title}
                    </p>
                  )}
                  {item.last_watched && (
                    <p className="text-xs text-muted-foreground/50 mt-0.5">
                      {formatDistanceToNow(new Date(item.last_watched), { addSuffix: true })}
                    </p>
                  )}
                </div>
              </Link>
              <button
                onClick={() => removeContinueWatching(item.id)}
                className="absolute top-2 left-2 w-6 h-6 rounded-full bg-black/60 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity hover:bg-destructive"
              >
                <X className="w-3 h-3 text-white" />
              </button>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}