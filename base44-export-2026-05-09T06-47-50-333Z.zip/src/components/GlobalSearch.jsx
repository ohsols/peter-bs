import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { Search, Film, Tv, X, Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { motion, AnimatePresence } from "framer-motion";

export default function GlobalSearch() {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState({ movies: [], shows: [] });
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const inputRef = useRef(null);
  const containerRef = useRef(null);
  const navigate = useNavigate();

  useEffect(() => {
    if (!query.trim()) {
      setResults({ movies: [], shows: [] });
      return;
    }
    const timeout = setTimeout(async () => {
      setLoading(true);
      const [movies, shows] = await Promise.all([
        base44.entities.Movie.list("-created_date", 100),
        base44.entities.TvShow.list("-created_date", 100),
      ]);
      const q = query.toLowerCase();
      setResults({
        movies: movies.filter((m) => m.title?.toLowerCase().includes(q)),
        shows: shows.filter((s) => s.title?.toLowerCase().includes(q)),
      });
      setLoading(false);
    }, 300);
    return () => clearTimeout(timeout);
  }, [query]);

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (containerRef.current && !containerRef.current.contains(e.target)) {
        setOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleSelect = (path) => {
    navigate(path);
    setQuery("");
    setOpen(false);
  };

  const hasResults = results.movies.length > 0 || results.shows.length > 0;
  const showDropdown = open && query.trim().length > 0;

  return (
    <div ref={containerRef} className="relative">
      <div className="flex items-center gap-2 px-3 py-2 bg-secondary border border-border rounded-lg w-48 md:w-64 focus-within:border-primary/50 transition-colors">
        <Search className="w-4 h-4 text-muted-foreground flex-shrink-0" />
        <input
          ref={inputRef}
          value={query}
          onChange={(e) => { setQuery(e.target.value); setOpen(true); }}
          onFocus={() => setOpen(true)}
          placeholder="Search..."
          className="bg-transparent text-sm text-foreground placeholder:text-muted-foreground outline-none w-full"
        />
        {query && (
          <button onClick={() => { setQuery(""); setResults({ movies: [], shows: [] }); }}>
            <X className="w-3.5 h-3.5 text-muted-foreground hover:text-foreground" />
          </button>
        )}
        {loading && <Loader2 className="w-3.5 h-3.5 text-muted-foreground animate-spin flex-shrink-0" />}
      </div>

      <AnimatePresence>
        {showDropdown && (
          <motion.div
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.15 }}
            className="absolute top-full mt-2 left-0 right-0 min-w-[280px] bg-card border border-border rounded-xl shadow-2xl z-50 overflow-hidden"
          >
            {!loading && !hasResults && (
              <p className="text-sm text-muted-foreground px-4 py-3">No results for "{query}"</p>
            )}

            {results.movies.length > 0 && (
              <div>
                <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground px-4 pt-3 pb-1">Movies</p>
                {results.movies.slice(0, 5).map((m) => (
                  <button
                    key={m.id}
                    onClick={() => handleSelect(`/movie/${m.id}`)}
                    className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-secondary transition-colors text-left"
                  >
                    {m.poster_url ? (
                      <img src={m.poster_url} alt={m.title} className="w-8 h-10 object-cover rounded flex-shrink-0" />
                    ) : (
                      <div className="w-8 h-10 bg-secondary flex items-center justify-center rounded flex-shrink-0">
                        <Film className="w-4 h-4 text-muted-foreground" />
                      </div>
                    )}
                    <div className="min-w-0">
                      <p className="text-sm font-medium truncate">{m.title}</p>
                      {m.year && <p className="text-xs text-muted-foreground">{m.year}</p>}
                    </div>
                  </button>
                ))}
              </div>
            )}

            {results.shows.length > 0 && (
              <div>
                <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground px-4 pt-3 pb-1">TV Shows</p>
                {results.shows.slice(0, 5).map((s) => (
                  <button
                    key={s.id}
                    onClick={() => handleSelect(`/show/${s.id}`)}
                    className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-secondary transition-colors text-left"
                  >
                    {s.poster_url ? (
                      <img src={s.poster_url} alt={s.title} className="w-8 h-10 object-cover rounded flex-shrink-0" />
                    ) : (
                      <div className="w-8 h-10 bg-secondary flex items-center justify-center rounded flex-shrink-0">
                        <Tv className="w-4 h-4 text-muted-foreground" />
                      </div>
                    )}
                    <div className="min-w-0">
                      <p className="text-sm font-medium truncate">{s.title}</p>
                      {s.year && <p className="text-xs text-muted-foreground">{s.year}</p>}
                    </div>
                  </button>
                ))}
              </div>
            )}
            <div className="h-2" />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}