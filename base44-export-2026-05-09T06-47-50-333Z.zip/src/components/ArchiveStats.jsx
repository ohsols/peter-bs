import { motion } from "framer-motion";
import { Film, Link2, Clock, HardDrive } from "lucide-react";

export default function ArchiveStats({ movies = [] }) {
  const totalMovies = movies.length;
  const activeLinks = movies.filter((m) => m.drive_link).length;
  const genres = [...new Set(movies.map((m) => m.genre).filter(Boolean))].length;

  const stats = [
    { label: "TOTAL FILMS", value: totalMovies.toString().padStart(3, "0"), icon: Film },
    { label: "ACTIVE LINKS", value: activeLinks.toString().padStart(3, "0"), icon: Link2 },
    { label: "GENRES", value: genres.toString().padStart(2, "0"), icon: HardDrive },
  ];

  return (
    <footer className="border-t border-border mt-32">
      <div className="max-w-[1600px] mx-auto px-6 md:px-12 py-16">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {stats.map((stat, i) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="flex items-center gap-4"
            >
              <div className="w-12 h-12 rounded-lg bg-secondary flex items-center justify-center border border-border">
                <stat.icon className="w-5 h-5 text-muted-foreground" />
              </div>
              <div>
                <div className="text-3xl font-black tracking-tighter font-mono">{stat.value}</div>
                <div className="text-xs text-muted-foreground tracking-widest uppercase">{stat.label}</div>
              </div>
            </motion.div>
          ))}
        </div>

        <div className="mt-12 pt-8 border-t border-border flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Film className="w-4 h-4 text-primary" />
            <span className="text-sm font-semibold tracking-tight">AETHER<span className="text-primary">.</span></span>
          </div>
          <p className="text-xs text-muted-foreground">Personal Cinema Archive · Built for film enthusiasts</p>
        </div>
      </div>
    </footer>
  );
}