import { motion } from "framer-motion";
import { Play, ChevronRight } from "lucide-react";
import { Link } from "react-router-dom";

const HERO_IMAGES = [
  "https://media.base44.com/images/public/69c87138642bccb8286e2cce/52ee9760f_generated_3095ae1d.png",
  "https://media.base44.com/images/public/69c87138642bccb8286e2cce/1d022ee54_generated_0a0973c4.png",
  "https://media.base44.com/images/public/69c87138642bccb8286e2cce/635a1bcb9_generated_b0a62efc.png"
];

export default function HeroSection({ featuredMovie }) {
  const heroImage = featuredMovie?.poster_url || HERO_IMAGES[0];
  const title = featuredMovie?.title || "AETHER STREAM";
  const description = featuredMovie?.description || "Your personal cinema archive. Upload films via Google Drive links and stream them instantly from your curated collection.";

  return (
    <section className="relative h-[85vh] min-h-[600px] overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0">
        <img
          src={heroImage}
          alt=""
          className="w-full h-full object-cover"
        />
        {/* Gradient overlays */}
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/60 to-background/30" />
        <div className="absolute inset-0 bg-gradient-to-r from-background/80 via-transparent to-transparent" />
      </div>

      {/* Light leak effect */}
      <div className="absolute inset-0 bg-primary/[0.03] mix-blend-overlay" />

      {/* Content */}
      <div className="relative h-full max-w-[1600px] mx-auto px-6 md:px-12 flex flex-col justify-end pb-24">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
          className="max-w-2xl"
        >
          {featuredMovie && (
            <div className="flex items-center gap-3 mb-4">
              <span className="px-3 py-1 text-xs font-semibold tracking-widest uppercase bg-primary/20 text-primary rounded-full border border-primary/30">
                Featured
              </span>
              {featuredMovie.year && (
                <span className="text-sm text-muted-foreground">{featuredMovie.year}</span>
              )}
              {featuredMovie.genre && (
                <span className="text-sm text-muted-foreground">·  {featuredMovie.genre}</span>
              )}
            </div>
          )}

          <h1 className="text-5xl md:text-7xl lg:text-8xl font-black tracking-tighter leading-[0.9] mb-6">
            {title.split("").map((char, i) => (
              <motion.span
                key={i}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.05 * i, duration: 0.5 }}
                className="inline-block"
              >
                {char === " " ? "\u00A0" : char}
              </motion.span>
            ))}
          </h1>

          <p className="text-lg text-muted-foreground leading-relaxed mb-8 max-w-lg">
            {description}
          </p>

          {featuredMovie && (
            <div className="flex items-center gap-4">
              <a
                href={featuredMovie.drive_link}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-3 px-8 py-4 bg-foreground text-background rounded-lg font-semibold hover:bg-foreground/90 transition-all hover:scale-105 active:scale-95"
              >
                <Play className="w-5 h-5 fill-current" />
                Stream Now
              </a>
              <Link
                to={`/movie/${featuredMovie.id}`}
                className="flex items-center gap-2 px-6 py-4 bg-secondary/80 backdrop-blur-sm text-foreground rounded-lg font-medium hover:bg-secondary transition-all border border-border"
              >
                Details
                <ChevronRight className="w-4 h-4" />
              </Link>
            </div>
          )}
        </motion.div>
      </div>

      {/* Bottom fade */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-background to-transparent" />
    </section>
  );
}