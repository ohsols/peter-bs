import { useRef } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import TvShowCard from "./TvShowCard";

export default function TvShowRow({ title, shows }) {
  const scrollRef = useRef(null);

  const scroll = (dir) => {
    if (!scrollRef.current) return;
    scrollRef.current.scrollBy({ left: dir === "left" ? -400 : 400, behavior: "smooth" });
  };

  if (!shows || shows.length === 0) return null;

  return (
    <section className="py-8">
      <div className="max-w-[1600px] mx-auto px-6 md:px-12">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold tracking-tight">{title}</h2>
          <div className="flex items-center gap-2">
            <button onClick={() => scroll("left")} className="w-9 h-9 rounded-full bg-secondary/80 border border-border flex items-center justify-center hover:bg-secondary transition-colors">
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button onClick={() => scroll("right")} className="w-9 h-9 rounded-full bg-secondary/80 border border-border flex items-center justify-center hover:bg-secondary transition-colors">
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
      <div
        ref={scrollRef}
        className="flex gap-4 overflow-x-auto px-6 md:px-12 pb-4"
        style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
      >
        {shows.map((show, i) => (
          <TvShowCard key={show.id} show={show} index={i} />
        ))}
      </div>
    </section>
  );
}