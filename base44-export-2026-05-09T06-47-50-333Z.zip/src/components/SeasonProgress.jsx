import { CheckCircle2 } from "lucide-react";

export default function SeasonProgress({ season, episodes, watchedIds }) {
  const watched = episodes.filter((ep) => watchedIds.has(ep.id)).length;
  const total = episodes.length;
  const pct = total === 0 ? 0 : Math.round((watched / total) * 100);

  return (
    <div className="mb-1">
      <div className="flex items-center justify-between mb-1.5">
        <span className="text-xs text-muted-foreground">
          {watched}/{total} episodes watched
        </span>
        {watched === total && total > 0 && (
          <span className="flex items-center gap-1 text-xs text-green-400 font-medium">
            <CheckCircle2 className="w-3 h-3" /> Complete
          </span>
        )}
      </div>
      <div className="h-1.5 w-full rounded-full bg-secondary overflow-hidden">
        <div
          className="h-full rounded-full bg-primary transition-all duration-500"
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  );
}