import { Link, useLocation, useNavigate } from "react-router-dom";
import { Film, Plus, Settings } from "lucide-react";
import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import GlobalSearch from "./GlobalSearch";
import { useProfile } from "@/hooks/useProfile";
import { useAuth } from "@/lib/AuthContext";

export default function Navbar({ onAddMovie }) {
  const location = useLocation();
  const navigate = useNavigate();
  const [scrolled, setScrolled] = useState(false);
  const { activeProfile } = useProfile();
  const { user } = useAuth();
  const isAdmin = user?.role === "admin";

  const isLibrary = location.pathname === "/library";
  const params = new URLSearchParams(location.search);
  const currentTab = params.get("tab") || "archive";

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <motion.nav
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled ? "bg-background/90 backdrop-blur-xl border-b border-border" : "bg-transparent"
      }`}
    >
      <div className="max-w-[1600px] mx-auto px-6 md:px-12 h-20 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-3 group">
          <div className="w-10 h-10 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center group-hover:bg-primary/20 transition-colors">
            <Film className="w-5 h-5 text-primary" />
          </div>
          <span className="text-xl font-bold tracking-tight">
            AETHER<span className="text-primary">.</span>
          </span>
        </Link>

        <div className="hidden md:flex items-center gap-8">
          <Link
            to="/"
            className={`text-sm font-medium tracking-wide transition-colors ${
              location.pathname === "/" ? "text-foreground" : "text-muted-foreground hover:text-foreground"
            }`}
          >
            Home
          </Link>
          <Link
            to="/library?tab=archive"
            className={`text-sm font-medium tracking-wide transition-colors ${
              isLibrary && currentTab === "archive" ? "text-foreground" : "text-muted-foreground hover:text-foreground"
            }`}
          >
            Films
          </Link>
          <Link
            to="/library?tab=tvshows"
            className={`text-sm font-medium tracking-wide transition-colors ${
              isLibrary && currentTab === "tvshows" ? "text-foreground" : "text-muted-foreground hover:text-foreground"
            }`}
          >
            TV Shows
          </Link>
          <Link
            to="/library?tab=anime"
            className={`text-sm font-medium tracking-wide transition-colors ${
              isLibrary && currentTab === "anime" ? "text-foreground" : "text-muted-foreground hover:text-foreground"
            }`}
          >
            Anime
          </Link>
        </div>

        <div className="flex items-center gap-3">
          <GlobalSearch />
          <div className="flex items-center gap-1">
            <Link to="/profiles" title="Switch Profile">
              {activeProfile ? (
                <div
                  className="w-9 h-9 rounded-lg overflow-hidden border-2 border-border hover:border-primary transition-colors flex-shrink-0"
                  style={{ background: activeProfile.avatar_url ? undefined : (activeProfile.color || "#805ad5") }}
                >
                  {activeProfile.avatar_url ? (
                    <img src={activeProfile.avatar_url} alt={activeProfile.name} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-white text-sm font-bold">
                      {activeProfile.name?.charAt(0).toUpperCase()}
                    </div>
                  )}
                </div>
              ) : (
                <div className="w-9 h-9 rounded-lg bg-secondary border border-border flex items-center justify-center hover:border-primary transition-colors">
                  <span className="text-xs text-muted-foreground font-medium">?</span>
                </div>
              )}
            </Link>
            <Link to="/settings" title="Account Settings" className="w-9 h-9 rounded-lg bg-secondary border border-border flex items-center justify-center hover:border-primary transition-colors">
              <Settings className="w-4 h-4 text-muted-foreground" />
            </Link>
          </div>
          {isAdmin && (
            <Link
              to="/admin"
              className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-muted-foreground hover:text-foreground border border-border rounded-lg bg-secondary hover:bg-secondary/80 transition-colors"
            >
              Admin
            </Link>
          )}
          {isAdmin && (
            <button
              onClick={onAddMovie}
              className="flex items-center gap-2 px-5 py-2.5 bg-primary text-primary-foreground rounded-lg text-sm font-semibold hover:bg-primary/90 transition-all hover:scale-105 active:scale-95"
            >
              <Plus className="w-4 h-4" />
              <span className="hidden sm:inline">Add Film</span>
            </button>
          )}
        </div>
      </div>
    </motion.nav>
  );
}