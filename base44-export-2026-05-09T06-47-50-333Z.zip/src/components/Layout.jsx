import { Outlet } from "react-router-dom";
import { useState } from "react";
import Navbar from "./Navbar";
import AddMovieModal from "./AddMovieModal";
import { useAuth } from "@/lib/AuthContext";

export default function Layout() {
  const [showAddModal, setShowAddModal] = useState(false);
  const [refreshKey, setRefreshKey] = useState(0);
  const { user } = useAuth();
  const isAdmin = user?.role === "admin";

  const handleMovieAdded = () => {
    setRefreshKey((k) => k + 1);
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Navbar onAddMovie={isAdmin ? () => setShowAddModal(true) : undefined} />
      <main key={refreshKey}>
        <Outlet context={{ onAddMovie: isAdmin ? () => setShowAddModal(true) : undefined, refreshKey, isAdmin }} />
      </main>
      {isAdmin && (
        <AddMovieModal
          open={showAddModal}
          onClose={() => setShowAddModal(false)}
          onMovieAdded={handleMovieAdded}
        />
      )}
    </div>
  );
}