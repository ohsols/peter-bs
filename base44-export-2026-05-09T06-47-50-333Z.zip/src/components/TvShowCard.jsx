import { motion } from "framer-motion";
import { Tv, Bookmark, Play } from "lucide-react";
import { Link } from "react-router-dom";
import { useState } from "react";
import { useWatchlist } from "@/hooks/useWatchlist.jsx";

export default function TvShowCard({ show, index = 0 }) {
  const [imageError, setImageError] = useState(false);
  const { isInWatchlist, toggle } = useWatchlist();

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ delay: index * 0.03, duration: 0.3 }}
      className="w-[160px] md:w-[190px] flex-shrink-0 group"
    >
      <Link to={`/show/${show.id}`} className="block">
        <div className="relative aspect-[2/3] rounded overflow-hidden bg-[#2a2a2a]">
          {show.poster_url && !imageError ? (
            <img
              src={show.poster_url}
              alt={show.title}
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
              onError={() => setImageError(true)}
            />
          ) : (
            <div className="w-full h-full flex flex-col items-center justify-center bg-[#1a1a1a] gap-2">
              <Tv className="w-8 h-8 text-white/10" />
              <span className="text-2xl font-black text-white/10 tracking-tighter">
                {show.title?.charAt(0) || "?"}
              </span>
            </div>
          )}

          {/* Hover overlay */}
          <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity duration-200 flex items-center justify-center">
            <div className="w-12 h-12 rounded-full bg-white/20 backdrop-blur-sm border-2 border-white flex items-center justify-center">
              <Play className="w-5 h-5 text-white fill-white ml-0.5" />
            </div>
          </div>

          {/* Bookmark button */}
          <button
            onClick={(e) => { e.preventDefault(); toggle({ ...show, item_type: "tvshow" }); }}
            className={`absolute top-2 right-2 w-6 h-6 rounded-full flex items-center justify-center transition-all opacity-0 group-hover:opacity-100 ${isInWatchlist(show.id) ? "bg-red-600 text-white" : "bg-black/70 text-white hover:bg-red-600"}`}
          >
            <Bookmark className={`w-3 h-3 ${isInWatchlist(show.id) ? "fill-current" : ""}`} />
          </button>
        </div>

        <div className="mt-1.5 px-0.5">
          <h3 className="text-xs font-semibold text-white truncate">{show.title}</h3>
          {(show.year || show.genre) && (
            <p className="text-[11px] text-gray-400 truncate mt-0.5">
              {[show.year, show.genre].filter(Boolean).join(" · ")}
            </p>
          )}
        </div>
      </Link>
    </motion.div>
  );
}