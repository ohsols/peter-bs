import { motion } from "framer-motion";
import { Play, ExternalLink, Bookmark } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useState } from "react";
import { useWatchlist } from "@/hooks/useWatchlist.jsx";

export default function MovieCard({ movie, index = 0, size = "normal" }) {
  const [imageError, setImageError] = useState(false);
  const [isHovered, setIsHovered] = useState(false);
  const { isInWatchlist, toggle } = useWatchlist();
  const navigate = useNavigate();

  const sizeClasses = {
    normal: "w-[160px] md:w-[190px] flex-shrink-0",
    large: "w-[260px] md:w-[320px] flex-shrink-0",
    grid: "w-full"
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ delay: index * 0.03, duration: 0.3 }}
      className={`${sizeClasses[size]} group cursor-pointer`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onClick={() => navigate(`/movie/${movie.id}`)}
    >
      <div className="relative aspect-[2/3] rounded overflow-hidden bg-[#2a2a2a]">
        {movie.poster_url && !imageError ? (
          <img
            src={movie.poster_url}
            alt={movie.title}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
            onError={() => setImageError(true)}
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-[#1a1a1a]">
            <span className="text-4xl font-black text-white/10 tracking-tighter">
              {movie.title?.charAt(0) || "?"}
            </span>
          </div>
        )}

        {/* Netflix-style hover overlay */}
        <div className={`absolute inset-0 bg-black/50 transition-opacity duration-200 ${isHovered ? "opacity-100" : "opacity-0"} flex items-center justify-center`}>
          <div className="w-12 h-12 rounded-full bg-white/20 backdrop-blur-sm border-2 border-white flex items-center justify-center">
            <Play className="w-5 h-5 text-white fill-white ml-0.5" />
          </div>
        </div>

        {/* Bookmark button */}
        <button
          onClick={(e) => { e.stopPropagation(); toggle({ ...movie, item_type: "movie" }); }}
          className={`absolute top-2 right-2 w-6 h-6 rounded-full flex items-center justify-center transition-all opacity-0 group-hover:opacity-100 ${isInWatchlist(movie.id) ? "bg-red-600 text-white" : "bg-black/70 text-white hover:bg-red-600"}`}
        >
          <Bookmark className={`w-3 h-3 ${isInWatchlist(movie.id) ? "fill-current" : ""}`} />
        </button>
      </div>

      <div className="mt-1.5 px-0.5">
        <h3 className="text-xs font-semibold text-white truncate">{movie.title}</h3>
        {(movie.year || movie.genre) && (
          <p className="text-[11px] text-gray-400 truncate mt-0.5">
            {[movie.year, movie.genre].filter(Boolean).join(" · ")}
          </p>
        )}
      </div>
    </motion.div>
  );
}