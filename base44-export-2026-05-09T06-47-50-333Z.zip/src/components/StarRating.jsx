import { useState } from "react";
import { Star } from "lucide-react";
import { useRatings } from "@/hooks/useRatings";
import { useProfile } from "@/hooks/useProfile";

export default function StarRating({ item, size = "md" }) {
  const { getRating, setRating } = useRatings();
  const { activeProfile } = useProfile();
  const [hovered, setHovered] = useState(0);
  const current = getRating(item?.id);
  const iconSize = size === "sm" ? "w-3 h-3" : "w-4 h-4";

  if (!activeProfile || !item) return null;

  const display = hovered || current;

  return (
    <div className="flex items-center gap-0.5 flex-wrap" onMouseLeave={() => setHovered(0)}>
      {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((star) => (
        <button
          key={star}
          onMouseEnter={() => setHovered(star)}
          onClick={(e) => { e.preventDefault(); e.stopPropagation(); setRating(item, star); }}
          className="transition-transform hover:scale-110"
        >
          <Star
            className={`${iconSize} transition-colors ${
              star <= display ? "fill-yellow-400 text-yellow-400" : "text-muted-foreground/30"
            }`}
          />
        </button>
      ))}
      {current > 0 && (
        <span className="ml-1.5 text-xs text-muted-foreground font-medium">{current}/10</span>
      )}
    </div>
  );
}