import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { X, Film, Tv, Loader2, User } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Link } from "react-router-dom";

export default function ActorModal({ actorName, onClose }) {
  const [movies, setMovies] = useState([]);
  const [shows, setShows] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadActorWork();
  }, [actorName]);

  const loadActorWork = async () => {
    setLoading(true);
    const [allMovies, allShows] = await Promise.all([
      base44.entities.Movie.list("-created_date", 200),
      base44.entities.TvShow.list("-created_date", 200),
    ]);
    setMovies(allMovies.filter(m => m.cast?.includes(actorName)));
    setShows(allShows.filter(s => s.cast?.includes(actorName)));
    setLoading(false);
  };

  const total = movies.length + shows.length;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 bg-background/80 backdrop-blur-sm flex items-center justify-center p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="bg-card border border-border rounded-2xl w-full max-w-xl max-h-[80vh] flex flex-col overflow-hidden"
          onClick={e => e.stopPropagation()}
        >
          {/* Header */}
          <div className="flex items-center gap-3 p-6 border-b border-border">
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
              <User className="w-5 h-5 text-primary" />
            </div>
            <div className="flex-1 min-w-0">
              <h2 className="font-bold text-lg truncate">{actorName}</h2>
              <p className="text-xs text-muted-foreground">{total} title{total !== 1 ? "s" : ""} in your library</p>
            </div>
            <button onClick={onClose} className="w-8 h-8 rounded-full hover:bg-secondary flex items-center justify-center text-muted-foreground transition-colors">
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Content */}
          <div className="overflow-y-auto flex-1 p-6 space-y-6">
            {loading ? (
              <div className="flex items-center justify-center py-12">
                <Loader2 className="w-6 h-6 animate-spin text-primary" />
              </div>
            ) : total === 0 ? (
              <div className="text-center py-12 text-muted-foreground">
                No other titles found in your library.
              </div>
            ) : (
              <>
                {movies.length > 0 && (
                  <div>
                    <h3 className="flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-muted-foreground mb-3">
                      <Film className="w-3.5 h-3.5" /> Movies
                    </h3>
                    <div className="space-y-2">
                      {movies.map(m => (
                        <Link key={m.id} to={`/movie/${m.id}`} onClick={onClose}
                          className="flex items-center gap-3 p-3 rounded-lg bg-secondary/50 hover:bg-secondary border border-border hover:border-primary/30 transition-all group"
                        >
                          <div className="w-9 h-12 rounded overflow-hidden bg-card flex-shrink-0">
                            {m.poster_url
                              ? <img src={m.poster_url} alt="" className="w-full h-full object-cover" />
                              : <div className="w-full h-full flex items-center justify-center text-sm font-bold text-muted-foreground/30">{m.title?.charAt(0)}</div>
                            }
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="font-medium text-sm truncate group-hover:text-primary transition-colors">{m.title}</p>
                            <p className="text-xs text-muted-foreground">{m.year}{m.genre ? ` · ${m.genre}` : ""}</p>
                          </div>
                        </Link>
                      ))}
                    </div>
                  </div>
                )}
                {shows.length > 0 && (
                  <div>
                    <h3 className="flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-muted-foreground mb-3">
                      <Tv className="w-3.5 h-3.5" /> TV Shows
                    </h3>
                    <div className="space-y-2">
                      {shows.map(s => (
                        <Link key={s.id} to={`/show/${s.id}`} onClick={onClose}
                          className="flex items-center gap-3 p-3 rounded-lg bg-secondary/50 hover:bg-secondary border border-border hover:border-primary/30 transition-all group"
                        >
                          <div className="w-9 h-12 rounded overflow-hidden bg-card flex-shrink-0">
                            {s.poster_url
                              ? <img src={s.poster_url} alt="" className="w-full h-full object-cover" />
                              : <div className="w-full h-full flex items-center justify-center text-sm font-bold text-muted-foreground/30">{s.title?.charAt(0)}</div>
                            }
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="font-medium text-sm truncate group-hover:text-primary transition-colors">{s.title}</p>
                            <p className="text-xs text-muted-foreground">{s.year}{s.genre ? ` · ${s.genre}` : ""}</p>
                          </div>
                        </Link>
                      ))}
                    </div>
                  </div>
                )}
              </>
            )}
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}