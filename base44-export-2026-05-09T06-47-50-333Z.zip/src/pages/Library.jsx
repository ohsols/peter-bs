import { useState, useEffect } from "react";
import { useOutletContext, useLocation } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Loader2, Search, SlidersHorizontal, Grid3X3, LayoutList, Plus, Bookmark, Film, Tv, Star, History, X, Sparkles } from "lucide-react";
import StarRating from "@/components/StarRating";
import { useRatings } from "@/hooks/useRatings";
import { useProfile } from "@/hooks/useProfile";
import { useWatchTracking } from "@/hooks/useWatchTracking";
import { formatDistanceToNow } from "date-fns";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import MovieCard from "../components/MovieCard";
import TvShowCard from "../components/TvShowCard";
import ArchiveStats from "../components/ArchiveStats";
import { motion } from "framer-motion";
import { useWatchlist } from "@/hooks/useWatchlist.jsx";

const GENRES = ["All", "Action", "Comedy", "Drama", "Horror", "Sci-Fi", "Thriller", "Romance", "Documentary", "Animation", "Fantasy", "Mystery", "Adventure", "Anime"];
const TV_GENRES = ["All", "Action", "Comedy", "Drama", "Horror", "Sci-Fi", "Thriller", "Romance", "Documentary", "Animation", "Fantasy", "Mystery", "Adventure"];

export default function Library() {
  const { onAddMovie, refreshKey, isAdmin } = useOutletContext();
  const location = useLocation();
  const [movies, setMovies] = useState([]);
  const [shows, setShows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [genre, setGenre] = useState("All");
  const [yearFilter, setYearFilter] = useState("All");
  const [sortBy, setSortBy] = useState("added");
  const [showGenre, setShowGenre] = useState("All");
  const [showYearFilter, setShowYearFilter] = useState("All");
  const [showSortBy, setShowSortBy] = useState("added");
  const [showSearch, setShowSearch] = useState("");
  const [view, setView] = useState("grid");
  const { watchlist } = useWatchlist();
  const { getRating, ratings } = useRatings();
  const { activeProfile } = useProfile();
  const { watchHistory, removeHistory } = useWatchTracking();

  const urlParams = new URLSearchParams(location.search);
  const activeTab = urlParams.get("tab") || "archive";

  useEffect(() => {
    loadData();
  }, [refreshKey]);

  const loadData = async () => {
    setLoading(true);
    const [movieData, showData] = await Promise.all([
      base44.entities.Movie.list("-created_date", 200),
      base44.entities.TvShow.list("-created_date", 200)
    ]);
    setMovies(movieData);
    setShows(showData);
    setLoading(false);
  };

  // Collect unique years
  const movieYears = ["All", ...Array.from(new Set(movies.map(m => m.year).filter(Boolean))).sort((a, b) => b - a).map(String)];
  const showYears = ["All", ...Array.from(new Set(shows.map(s => s.year).filter(Boolean))).sort((a, b) => b - a).map(String)];

  const applySort = (items, sort) => {
    const arr = [...items];
    if (sort === "year_desc") return arr.sort((a, b) => (b.year || 0) - (a.year || 0));
    if (sort === "year_asc") return arr.sort((a, b) => (a.year || 0) - (b.year || 0));
    if (sort === "title") return arr.sort((a, b) => a.title?.localeCompare(b.title));
    return arr; // "added" = default order
  };

  const filtered = applySort(
    movies.filter((m) => {
      const matchesSearch = !search || m.title?.toLowerCase().includes(search.toLowerCase()) || m.director?.toLowerCase().includes(search.toLowerCase());
      const matchesGenre = genre === "All" || m.genre === genre;
      const matchesYear = yearFilter === "All" || String(m.year) === yearFilter;
      return matchesSearch && matchesGenre && matchesYear;
    }),
    sortBy
  );

  const filteredShows = (genreFilter, tab) => {
    const base = tab === "anime" ? shows.filter(s => s.genre === "Anime") : shows.filter(s => s.genre !== "Anime");
    return applySort(
      base.filter((s) => {
        const matchesSearch = !showSearch || s.title?.toLowerCase().includes(showSearch.toLowerCase());
        const matchesGenre = genreFilter === "All" || s.genre === genreFilter;
        const matchesYear = showYearFilter === "All" || String(s.year) === showYearFilter;
        return matchesSearch && matchesGenre && matchesYear;
      }),
      showSortBy
    );
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-6 h-6 animate-spin text-primary" />
      </div>
    );
  }

  // Build watchlist items resolved against actual movie/show data
  const watchlistMovies = watchlist
    .filter((w) => w.item_type === "movie")
    .map((w) => movies.find((m) => m.id === w.item_id))
    .filter(Boolean);

  const watchlistShows = watchlist
    .filter((w) => w.item_type === "tvshow")
    .map((w) => shows.find((s) => s.id === w.item_id))
    .filter(Boolean);

  return (
    <div className="pt-24 min-h-screen">
      <div className="max-w-[1600px] mx-auto px-6 md:px-12">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-4xl md:text-6xl font-black tracking-tighter mb-2">The Archive</h1>
          <p className="text-muted-foreground text-lg">
            {movies.length} film{movies.length !== 1 ? "s" : ""} · {shows.length} show{shows.length !== 1 ? "s" : ""} in your collection
          </p>
        </motion.div>

        {/* Tabs */}
        <div className="flex items-center gap-1 mb-8 border-b border-border overflow-x-auto">
          {[
            { key: "archive", label: "All Films", icon: null },
            { key: "tvshows", label: "TV Shows", icon: <Tv className="w-4 h-4" />, count: shows.filter(s => s.genre !== "Anime").length },
            { key: "anime", label: "Anime", icon: <Sparkles className="w-4 h-4" />, count: shows.filter(s => s.genre === "Anime").length },
            { key: "watchlist", label: "My Watchlist", icon: <Bookmark className="w-4 h-4" />, count: watchlist.length },
            ...(activeProfile ? [
              { key: "ratings", label: "My Ratings", icon: <Star className="w-4 h-4" />, count: ratings.length },
              { key: "history", label: "History", icon: <History className="w-4 h-4" />, count: watchHistory.length },
            ] : []),
          ].map(({ key, label, icon, count }) => (
            <a
              key={key}
              href={`/library?tab=${key}`}
              className={`flex items-center gap-2 px-5 py-3 text-sm font-semibold border-b-2 transition-colors -mb-px whitespace-nowrap ${activeTab === key ? "border-primary text-foreground" : "border-transparent text-muted-foreground hover:text-foreground"}`}
            >
              {icon}
              {label}
              {count > 0 && (
                <span className="px-1.5 py-0.5 text-xs bg-primary text-primary-foreground rounded-full leading-none">
                  {count}
                </span>
              )}
            </a>
          ))}
        </div>

        {activeTab === "watchlist" ? (
          /* Watchlist Section */
          watchlist.length === 0 ? (
            <div className="text-center py-24">
              <Bookmark className="w-10 h-10 text-muted-foreground/30 mx-auto mb-4" />
              <p className="text-muted-foreground">Your watchlist is empty.</p>
              <p className="text-sm text-muted-foreground/60 mt-1">Bookmark movies and shows using the bookmark icon on their cards.</p>
            </div>
          ) : (
            <div className="space-y-8">
              {watchlistMovies.length > 0 && (
                <div>
                  <h2 className="flex items-center gap-2 text-sm font-semibold text-muted-foreground uppercase tracking-widest mb-4">
                    <Film className="w-4 h-4" /> Movies
                  </h2>
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-5">
                    {watchlistMovies.map((movie, i) => (
                      <MovieCard key={movie.id} movie={movie} index={i} size="grid" />
                    ))}
                  </div>
                </div>
              )}
              {watchlistShows.length > 0 && (
                <div>
                  <h2 className="flex items-center gap-2 text-sm font-semibold text-muted-foreground uppercase tracking-widest mb-4">
                    <Tv className="w-4 h-4" /> TV Shows
                  </h2>
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-5">
                    {watchlistShows.map((show, i) => (
                      <TvShowCard key={show.id} show={show} index={i} />
                    ))}
                  </div>
                </div>
              )}
            </div>
          )
        ) : activeTab === "ratings" ? (
          /* Ratings Section */
          ratings.length === 0 ? (
            <div className="text-center py-24">
              <Star className="w-10 h-10 text-muted-foreground/30 mx-auto mb-4" />
              <p className="text-muted-foreground">You haven't rated anything yet.</p>
              <p className="text-sm text-muted-foreground/60 mt-1">Rate movies and shows using the star icons on their detail pages.</p>
            </div>
          ) : (
            <div className="space-y-2">
              {[...ratings]
                .sort((a, b) => b.stars - a.stars)
                .map((r) => {
                  const movie = movies.find((m) => m.id === r.item_id);
                  const show = shows.find((s) => s.id === r.item_id);
                  const item = movie || show;
                  if (!item) return null;
                  const href = movie ? `/movie/${item.id}` : `/show/${item.id}`;
                  return (
                    <motion.a
                      key={r.id}
                      href={href}
                      initial={{ opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="flex items-center gap-4 px-5 py-4 bg-card rounded-lg border border-border hover:border-primary/30 transition-all group"
                    >
                      <div className="w-12 h-16 rounded-md overflow-hidden bg-secondary flex-shrink-0">
                        {item.poster_url ? (
                          <img src={item.poster_url} alt="" className="w-full h-full object-cover" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-lg font-bold text-muted-foreground/30">
                            {item.title?.charAt(0)}
                          </div>
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <h3 className="font-semibold truncate group-hover:text-primary transition-colors">{item.title}</h3>
                        <div className="flex items-center gap-2 mt-1">
                          {item.year && <span className="text-xs text-muted-foreground">{item.year}</span>}
                          {item.genre && <span className="text-xs text-muted-foreground">· {item.genre}</span>}
                          <span className="text-xs text-muted-foreground/50">· {r.item_type === "movie" ? "Film" : "Series"}</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-1 flex-shrink-0">
                        <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                        <span className="text-sm font-semibold text-yellow-400">{r.stars}</span>
                        <span className="text-xs text-muted-foreground">/10</span>
                      </div>
                    </motion.a>
                  );
                })}
            </div>
          )
        ) : activeTab === "history" ? (
          /* Watch History Section */
          watchHistory.length === 0 ? (
            <div className="text-center py-24">
              <History className="w-10 h-10 text-muted-foreground/30 mx-auto mb-4" />
              <p className="text-muted-foreground">No watch history yet.</p>
              <p className="text-sm text-muted-foreground/60 mt-1">Start watching movies and shows to build your history.</p>
            </div>
          ) : (
            <div className="space-y-2">
              {watchHistory.map((h) => {
                const href = h.item_type === "movie" ? `/movie/${h.item_id}` : `/show/${h.item_id}`;
                return (
                  <motion.div
                    key={h.id}
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="flex items-center gap-4 px-5 py-4 bg-card rounded-lg border border-border group"
                  >
                    <a href={href} className="flex items-center gap-4 flex-1 min-w-0 hover:opacity-80 transition-opacity">
                      <div className="w-12 h-16 rounded-md overflow-hidden bg-secondary flex-shrink-0">
                        {h.item_poster ? (
                          <img src={h.item_poster} alt="" className="w-full h-full object-cover" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-lg font-bold text-muted-foreground/30">
                            {h.item_title?.charAt(0)}
                          </div>
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <h3 className="font-semibold truncate">{h.item_title}</h3>
                        {h.episode_title && (
                          <p className="text-xs text-muted-foreground">S{h.season_number} E{h.episode_number} · {h.episode_title}</p>
                        )}
                        <div className="flex items-center gap-2 mt-1">
                          <span className="text-xs text-muted-foreground/50">{h.item_type === "movie" ? "Film" : "Series"}</span>
                          {h.watched_at && (
                            <span className="text-xs text-muted-foreground/50">· {formatDistanceToNow(new Date(h.watched_at), { addSuffix: true })}</span>
                          )}
                        </div>
                      </div>
                    </a>
                    <button
                      onClick={() => removeHistory(h.id)}
                      className="flex-shrink-0 w-7 h-7 rounded-full hover:bg-destructive/20 flex items-center justify-center text-muted-foreground/40 hover:text-destructive transition-colors opacity-0 group-hover:opacity-100"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </motion.div>
                );
              })}
            </div>
          )
        ) : activeTab === "tvshows" ? (
          /* TV Shows Section */
          <>
            <div className="flex flex-wrap items-center gap-3 mb-8">
              <div className="relative flex-1 min-w-[200px] max-w-sm">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input value={showSearch} onChange={(e) => setShowSearch(e.target.value)} placeholder="Search shows..." className="pl-11 h-10 bg-card border-border" />
              </div>
              <Select value={showGenre} onValueChange={setShowGenre}>
                <SelectTrigger className="w-[140px] h-10 bg-card border-border"><SelectValue placeholder="Genre" /></SelectTrigger>
                <SelectContent>{TV_GENRES.map((g) => <SelectItem key={g} value={g}>{g}</SelectItem>)}</SelectContent>
              </Select>
              <Select value={showYearFilter} onValueChange={setShowYearFilter}>
                <SelectTrigger className="w-[120px] h-10 bg-card border-border"><SelectValue placeholder="Year" /></SelectTrigger>
                <SelectContent>{showYears.map((y) => <SelectItem key={y} value={y}>{y === "All" ? "All Years" : y}</SelectItem>)}</SelectContent>
              </Select>
              <Select value={showSortBy} onValueChange={setShowSortBy}>
                <SelectTrigger className="w-[150px] h-10 bg-card border-border"><SelectValue placeholder="Sort by" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="added">Recently Added</SelectItem>
                  <SelectItem value="year_desc">Newest First</SelectItem>
                  <SelectItem value="year_asc">Oldest First</SelectItem>
                  <SelectItem value="title">Title A–Z</SelectItem>
                </SelectContent>
              </Select>
            </div>
            {filteredShows(showGenre, "tvshows").length === 0 ? (
              <div className="text-center py-24">
                <Tv className="w-10 h-10 text-muted-foreground/30 mx-auto mb-4" />
                <p className="text-muted-foreground">No TV shows found.</p>
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-5">
                {filteredShows(showGenre, "tvshows").map((show, i) => <TvShowCard key={show.id} show={show} index={i} />)}
              </div>
            )}
          </>
        ) : activeTab === "anime" ? (
          /* Anime Section */
          <>
            <div className="flex flex-wrap items-center gap-3 mb-8">
              <div className="relative flex-1 min-w-[200px] max-w-sm">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input value={showSearch} onChange={(e) => setShowSearch(e.target.value)} placeholder="Search anime..." className="pl-11 h-10 bg-card border-border" />
              </div>
              <Select value={showYearFilter} onValueChange={setShowYearFilter}>
                <SelectTrigger className="w-[120px] h-10 bg-card border-border"><SelectValue placeholder="Year" /></SelectTrigger>
                <SelectContent>{showYears.map((y) => <SelectItem key={y} value={y}>{y === "All" ? "All Years" : y}</SelectItem>)}</SelectContent>
              </Select>
              <Select value={showSortBy} onValueChange={setShowSortBy}>
                <SelectTrigger className="w-[150px] h-10 bg-card border-border"><SelectValue placeholder="Sort by" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="added">Recently Added</SelectItem>
                  <SelectItem value="year_desc">Newest First</SelectItem>
                  <SelectItem value="year_asc">Oldest First</SelectItem>
                  <SelectItem value="title">Title A–Z</SelectItem>
                </SelectContent>
              </Select>
            </div>
            {filteredShows(showGenre, "anime").length === 0 ? (
              <div className="text-center py-24">
                <Sparkles className="w-10 h-10 text-muted-foreground/30 mx-auto mb-4" />
                <p className="text-muted-foreground">No anime found.</p>
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-5">
                {filteredShows(showGenre, "anime").map((show, i) => <TvShowCard key={show.id} show={show} index={i} />)}
              </div>
            )}
          </>
        ) : (
          /* Archive Section */
          <>
            <div className="flex flex-col md:flex-row items-start md:items-center gap-3 mb-10 flex-wrap">
              <div className="relative flex-1 min-w-[200px] max-w-sm">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Search films..."
                  className="pl-11 h-10 bg-card border-border"
                />
              </div>
              <Select value={genre} onValueChange={setGenre}>
                <SelectTrigger className="w-[140px] h-10 bg-card border-border">
                  <SelectValue placeholder="Genre" />
                </SelectTrigger>
                <SelectContent>
                  {GENRES.map((g) => (
                    <SelectItem key={g} value={g}>{g}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={yearFilter} onValueChange={setYearFilter}>
                <SelectTrigger className="w-[120px] h-10 bg-card border-border">
                  <SelectValue placeholder="Year" />
                </SelectTrigger>
                <SelectContent>
                  {movieYears.map((y) => (
                    <SelectItem key={y} value={y}>{y === "All" ? "All Years" : y}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-[150px] h-10 bg-card border-border">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="added">Recently Added</SelectItem>
                  <SelectItem value="year_desc">Newest First</SelectItem>
                  <SelectItem value="year_asc">Oldest First</SelectItem>
                  <SelectItem value="title">Title A–Z</SelectItem>
                </SelectContent>
              </Select>
              <div className="flex items-center gap-1 bg-card rounded-lg border border-border p-1">
                <button
                  onClick={() => setView("grid")}
                  className={`w-9 h-9 rounded-md flex items-center justify-center transition-colors ${view === "grid" ? "bg-secondary text-foreground" : "text-muted-foreground hover:text-foreground"}`}
                >
                  <Grid3X3 className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setView("list")}
                  className={`w-9 h-9 rounded-md flex items-center justify-center transition-colors ${view === "list" ? "bg-secondary text-foreground" : "text-muted-foreground hover:text-foreground"}`}
                >
                  <LayoutList className="w-4 h-4" />
                </button>
              </div>
              {isAdmin && (
                <button
                  onClick={onAddMovie}
                  className="flex items-center gap-2 px-5 py-2.5 bg-primary text-primary-foreground rounded-lg text-sm font-semibold hover:bg-primary/90 transition-all"
                >
                  <Plus className="w-4 h-4" />
                  Add Film
                </button>
              )}
            </div>

            {filtered.length === 0 ? (
              <div className="text-center py-24">
                <p className="text-muted-foreground mb-4">No films found</p>
                {movies.length === 0 && isAdmin && (
                  <button onClick={onAddMovie} className="text-primary hover:underline text-sm font-medium">
                    Add your first film
                  </button>
                )}
              </div>
            ) : view === "grid" ? (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-5">
                {filtered.map((movie, i) => (
                  <MovieCard key={movie.id} movie={movie} index={i} size="grid" />
                ))}
              </div>
            ) : (
              <div className="space-y-2">
                {filtered.map((movie, i) => (
                  <ListItem key={movie.id} movie={movie} index={i} />
                ))}
              </div>
            )}
          </>
        )}
      </div>

      <ArchiveStats movies={movies} />
    </div>
  );
}

function ListItem({ movie, index }) {
  return (
    <motion.a
      href={`/movie/${movie.id}`}
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.03 }}
      className="flex items-center gap-4 px-5 py-4 bg-card rounded-lg border border-border hover:border-primary/30 transition-all group"
    >
      <div className="w-12 h-16 rounded-md overflow-hidden bg-secondary flex-shrink-0">
        {movie.poster_url ? (
          <img src={movie.poster_url} alt="" className="w-full h-full object-cover" />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-lg font-bold text-muted-foreground/30">
            {movie.title?.charAt(0)}
          </div>
        )}
      </div>
      <div className="flex-1 min-w-0">
        <h3 className="font-semibold truncate group-hover:text-primary transition-colors">{movie.title}</h3>
        <div className="flex items-center gap-3 text-xs text-muted-foreground mt-1">
          {movie.year && <span>{movie.year}</span>}
          {movie.genre && <span>·  {movie.genre}</span>}
          {movie.director && <span>·  {movie.director}</span>}
        </div>
      </div>
      <div className="w-2.5 h-2.5 rounded-full bg-primary animate-pulse-glow flex-shrink-0" />
    </motion.a>
  );
}