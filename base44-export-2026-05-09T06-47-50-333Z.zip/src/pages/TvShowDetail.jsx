import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { ArrowLeft, Tv, Play, Trash2, Loader2, Bookmark, CheckCircle2, Users } from "lucide-react";
import ActorModal from "@/components/ActorModal";
import { useWatchlist } from "@/hooks/useWatchlist.jsx";
import { useProfile } from "@/hooks/useProfile";
import { useWatchTracking } from "@/hooks/useWatchTracking";
import { useAuth } from "@/lib/AuthContext";
import { motion } from "framer-motion";
import SeasonProgress from "@/components/SeasonProgress";
import StarRating from "@/components/StarRating";

function getEmbedUrl(link) {
  if (!link) return null;
  const fileMatch = link.match(/\/file\/d\/([a-zA-Z0-9_-]+)/);
  if (fileMatch) return `https://drive.google.com/file/d/${fileMatch[1]}/preview`;
  const openMatch = link.match(/[?&]id=([a-zA-Z0-9_-]+)/);
  if (openMatch) return `https://drive.google.com/file/d/${openMatch[1]}/preview`;
  return link;
}

export default function TvShowDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { isInWatchlist, toggle } = useWatchlist();
  const { activeProfile } = useProfile();
  const { markWatching } = useWatchTracking();
  const { user } = useAuth();
  const isAdmin = user?.role === "admin";
  const [show, setShow] = useState(null);
  const [episodes, setEpisodes] = useState([]);
  const [watchedIds, setWatchedIds] = useState(new Set());
  const [loading, setLoading] = useState(true);
  const [activeEpisode, setActiveEpisode] = useState(null);
  const [deleting, setDeleting] = useState(false);
  const [selectedActor, setSelectedActor] = useState(null);

  useEffect(() => {
    loadData();
  }, [id]);

  const loadData = async () => {
    setLoading(true);
    const [showData, episodeData, watchedData] = await Promise.all([
      base44.entities.TvShow.filter({ id }),
      base44.entities.Episode.filter({ show_id: id }, "season_number"),
      activeProfile?.user_email
        ? base44.entities.WatchedEpisode.filter({ show_id: id, user_email: activeProfile.user_email })
        : Promise.resolve([])
    ]);
    setShow(showData[0] || null);
    setEpisodes(episodeData);
    setWatchedIds(new Set(watchedData.map((w) => w.episode_id)));
    if (episodeData.length > 0) setActiveEpisode(episodeData[0]);
    setLoading(false);
  };

  const toggleWatched = async (ep) => {
    if (!activeProfile?.user_email) return;
    if (watchedIds.has(ep.id)) {
      const records = await base44.entities.WatchedEpisode.filter({ episode_id: ep.id, user_email: activeProfile.user_email });
      await Promise.all(records.map((r) => base44.entities.WatchedEpisode.delete(r.id)));
      setWatchedIds((prev) => { const n = new Set(prev); n.delete(ep.id); return n; });
    } else {
      await base44.entities.WatchedEpisode.create({ user_email: activeProfile.user_email, episode_id: ep.id, show_id: id });
      setWatchedIds((prev) => new Set([...prev, ep.id]));
    }
  };

  const handleDelete = async () => {
    if (!confirm(`Delete "${show.title}" and all its episodes?`)) return;
    setDeleting(true);
    await Promise.all([
      base44.entities.TvShow.delete(show.id),
      ...episodes.map(ep => base44.entities.Episode.delete(ep.id))
    ]);
    navigate("/");
  };

  // Group by season
  const seasons = episodes.reduce((acc, ep) => {
    const s = ep.season_number || 1;
    if (!acc[s]) acc[s] = [];
    acc[s].push(ep);
    return acc;
  }, {});

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-6 h-6 animate-spin text-primary" />
      </div>
    );
  }

  if (!show) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-muted-foreground">Show not found.</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-24 pb-16">
      <div className="max-w-[1400px] mx-auto px-6 md:px-12">
        {/* Back */}
        <button onClick={() => navigate(-1)} className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors mb-8 text-sm">
          <ArrowLeft className="w-4 h-4" />
          Back
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
          {/* Left: Info */}
          <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} className="lg:col-span-1">
            <div className="aspect-[2/3] rounded-xl overflow-hidden bg-secondary mb-6">
              {show.poster_url ? (
                <img src={show.poster_url} alt={show.title} className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <Tv className="w-16 h-16 text-muted-foreground/20" />
                </div>
              )}
            </div>
            <h1 className="text-3xl font-black tracking-tight mb-2">{show.title}</h1>
            <div className="flex items-center gap-3 mb-4 flex-wrap">
              <span className="px-2 py-0.5 text-xs font-bold tracking-widest uppercase bg-primary/20 text-primary rounded border border-primary/30">SERIES</span>
              {show.year && <span className="text-sm text-muted-foreground">{show.year}</span>}
              {show.genre && <span className="text-sm text-muted-foreground">{show.genre}</span>}
              <span className="text-sm text-muted-foreground">{episodes.length} episodes</span>
            </div>
            {show.description && <p className="text-sm text-muted-foreground leading-relaxed mb-6">{show.description}</p>}
            <div className="mb-4">
              <StarRating item={{ ...show, item_type: "tvshow" }} />
            </div>
            <button
              onClick={() => toggle({ ...show, item_type: "tvshow" })}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm transition-colors border mb-3 ${isInWatchlist(show.id) ? "bg-primary/10 border-primary/30 text-primary" : "bg-secondary border-border text-foreground hover:bg-secondary/80"}`}
            >
              <Bookmark className={`w-4 h-4 ${isInWatchlist(show.id) ? "fill-current" : ""}`} />
              {isInWatchlist(show.id) ? "Saved to Watch Later" : "Watch Later"}
            </button>
            {/* Cast */}
            {show.cast && show.cast.length > 0 && (
              <div className="border-t border-border pt-4">
                <h3 className="flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-muted-foreground mb-3">
                  <Users className="w-3.5 h-3.5" /> Cast
                </h3>
                <div className="flex flex-wrap gap-2">
                  {show.cast.map((actor) => (
                    <button
                      key={actor}
                      onClick={() => setSelectedActor(actor)}
                      className="px-3 py-1.5 text-xs font-medium bg-secondary hover:bg-primary/10 hover:text-primary border border-border hover:border-primary/30 rounded-full transition-all"
                    >
                      {actor}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {isAdmin && (
              <button onClick={handleDelete} disabled={deleting} className="flex items-center gap-2 px-4 py-2 bg-destructive/10 text-destructive rounded-lg text-sm hover:bg-destructive/20 transition-colors border border-destructive/20">
                {deleting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
                Delete Show
              </button>
            )}
          </motion.div>

          {/* Right: Player + Episodes */}
          <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="lg:col-span-2 space-y-6">
            {/* Player */}
            {activeEpisode && (
              <div>
                <div className="aspect-video rounded-xl overflow-hidden bg-black border border-border">
                  <iframe
                    src={getEmbedUrl(activeEpisode.drive_link)}
                    className="w-full h-full"
                    allow="autoplay"
                    allowFullScreen
                  />
                </div>
                <p className="mt-3 text-sm font-medium text-muted-foreground">
                  S{activeEpisode.season_number || 1} E{activeEpisode.episode_number || ""} — {activeEpisode.title}
                </p>
              </div>
            )}

            {/* Episode list by season */}
            {Object.entries(seasons).map(([season, eps]) => (
              <div key={season}>
                <div className="mb-3">
                  <h3 className="text-sm font-semibold uppercase tracking-widest text-muted-foreground mb-2">Season {season}</h3>
                  <SeasonProgress season={season} episodes={eps} watchedIds={watchedIds} />
                </div>
                <div className="space-y-2">
                  {eps.map((ep) => {
                    const isWatched = watchedIds.has(ep.id);
                    return (
                      <div key={ep.id} className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg border transition-all ${
                        activeEpisode?.id === ep.id
                          ? "bg-primary/10 border-primary/30 text-foreground"
                          : "bg-secondary/50 border-border text-muted-foreground"
                      }`}>
                        <button
                          onClick={() => { setActiveEpisode(ep); markWatching({ id: show.id, item_type: "tvshow", title: show.title, poster_url: show.poster_url, episode_id: ep.id, episode_title: ep.title, season_number: ep.season_number || 1, episode_number: ep.episode_number }); }}
                          className="flex items-center gap-3 flex-1 text-left hover:text-foreground transition-colors"
                        >
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${activeEpisode?.id === ep.id ? "bg-primary text-primary-foreground" : "bg-secondary"}`}>
                            {activeEpisode?.id === ep.id ? <Play className="w-3 h-3 fill-current" /> : <span className="text-xs font-bold">{ep.episode_number || "?"}</span>}
                          </div>
                          <span className={`text-sm font-medium truncate ${isWatched ? "line-through opacity-60" : ""}`}>{ep.title}</span>
                        </button>
                        {activeProfile && (
                          <button
                            onClick={() => toggleWatched(ep)}
                            className={`flex-shrink-0 w-7 h-7 rounded-full flex items-center justify-center transition-all ${isWatched ? "bg-green-500/20 text-green-400" : "bg-secondary hover:bg-green-500/20 hover:text-green-400 text-muted-foreground/40"}`}
                            title={isWatched ? "Mark unwatched" : "Mark watched"}
                          >
                            <CheckCircle2 className={`w-4 h-4 ${isWatched ? "fill-green-500/20" : ""}`} />
                          </button>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}
          </motion.div>
        </div>
      </div>
      {selectedActor && (
        <ActorModal actorName={selectedActor} onClose={() => setSelectedActor(null)} />
      )}
    </div>
  );
}