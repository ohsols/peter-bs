import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { useProfile } from "@/hooks/useProfile";
import { useAuth } from "@/lib/AuthContext";
import { motion, AnimatePresence } from "framer-motion";
import { Plus, Pencil, Check, X, Loader2, Upload, Trash2 } from "lucide-react";

const COLORS = ["#e53e3e", "#dd6b20", "#d69e2e", "#38a169", "#3182ce", "#805ad5", "#d53f8c"];
const DEFAULT_FORM = { name: "", color: COLORS[0], avatar_url: "" };

export default function WhoIsWatching() {
  const navigate = useNavigate();
  const { selectProfile } = useProfile();
  const { user } = useAuth();

  const [profiles, setProfiles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState(null); // null | "new" | profile object
  const [form, setForm] = useState(DEFAULT_FORM);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const fileRef = useRef();

  useEffect(() => {
    if (user?.email) loadProfiles();
  }, [user]);

  const loadProfiles = async () => {
    const data = await base44.entities.Profile.filter({ user_email: user.email });
    setProfiles(data);
    setLoading(false);
  };

  const openNew = () => {
    setForm({ ...DEFAULT_FORM, color: COLORS[profiles.length % COLORS.length] });
    setModal("new");
  };

  const openEdit = (p) => {
    setForm({ name: p.name, color: p.color || COLORS[0], avatar_url: p.avatar_url || "" });
    setModal(p);
  };

  const closeModal = () => {
    if (saving || uploading) return;
    setModal(null);
  };

  const handleUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setUploading(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    setForm((f) => ({ ...f, avatar_url: file_url }));
    setUploading(false);
    e.target.value = "";
  };

  const handleSave = async () => {
    if (!form.name.trim() || saving) return;
    setSaving(true);
    const payload = {
      user_email: user.email,
      name: form.name.trim(),
      color: form.color,
      avatar_url: form.avatar_url,
    };
    if (modal === "new") {
      const created = await base44.entities.Profile.create(payload);
      setProfiles((prev) => [...prev, created]);
    } else {
      const updated = await base44.entities.Profile.update(modal.id, payload);
      setProfiles((prev) => prev.map((p) => (p.id === modal.id ? updated : p)));
    }
    setSaving(false);
    setModal(null);
  };

  const handleDelete = async () => {
    if (!confirm(`Delete profile "${modal.name}"?`)) return;
    await base44.entities.Profile.delete(modal.id);
    setProfiles((prev) => prev.filter((p) => p.id !== modal.id));
    setModal(null);
  };

  const handleSelect = (p) => {
    selectProfile(p);
    navigate("/");
  };

  if (!user || loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="w-6 h-6 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center px-6">
      <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} className="text-center w-full max-w-2xl">
        <h1 className="text-4xl md:text-5xl font-black tracking-tighter mb-2">Who's Watching?</h1>
        <p className="text-muted-foreground mb-12">Select your profile to continue</p>

        <div className="flex flex-wrap justify-center gap-8 mb-12">
          {profiles.map((p) => (
            <motion.div key={p.id} initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="flex flex-col items-center gap-3 group">
              <div className="relative cursor-pointer" onClick={() => handleSelect(p)}>
                <div
                  className="w-28 h-28 rounded-xl overflow-hidden border-2 border-transparent group-hover:border-primary transition-all"
                  style={{ background: p.avatar_url ? undefined : (p.color || COLORS[0]) }}
                >
                  {p.avatar_url ? (
                    <img src={p.avatar_url} alt={p.name} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-4xl font-black text-white/80">
                      {p.name.charAt(0).toUpperCase()}
                    </div>
                  )}
                </div>
                <button
                  onClick={(e) => { e.stopPropagation(); openEdit(p); }}
                  className="absolute -top-2 -right-2 w-7 h-7 rounded-full bg-secondary border border-border flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity hover:bg-primary hover:text-primary-foreground"
                >
                  <Pencil className="w-3 h-3" />
                </button>
              </div>
              <span className="text-sm font-semibold text-muted-foreground group-hover:text-foreground transition-colors">
                {p.name}
              </span>
            </motion.div>
          ))}

          {/* Add new */}
          <div className="flex flex-col items-center gap-3 cursor-pointer group" onClick={openNew}>
            <div className="w-28 h-28 rounded-xl border-2 border-dashed border-border flex items-center justify-center group-hover:border-primary transition-colors">
              <Plus className="w-8 h-8 text-muted-foreground group-hover:text-primary transition-colors" />
            </div>
            <span className="text-sm font-semibold text-muted-foreground group-hover:text-foreground transition-colors">
              Add Profile
            </span>
          </div>
        </div>
      </motion.div>

      {/* Modal */}
      <AnimatePresence>
        {modal !== null && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-6"
            onClick={closeModal}
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-card border border-border rounded-2xl p-8 w-full max-w-sm space-y-5"
            >
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-bold">{modal === "new" ? "New Profile" : "Edit Profile"}</h2>
                <button onClick={closeModal} className="w-8 h-8 rounded-lg bg-secondary flex items-center justify-center hover:bg-secondary/80">
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Avatar */}
              <div className="flex flex-col items-center gap-3">
                <div
                  className="relative w-24 h-24 rounded-xl overflow-hidden cursor-pointer border border-border"
                  style={{ background: form.avatar_url ? undefined : form.color }}
                  onClick={() => fileRef.current?.click()}
                >
                  {form.avatar_url ? (
                    <img src={form.avatar_url} alt="avatar" className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex flex-col items-center justify-center gap-1 text-white/70">
                      <Upload className="w-5 h-5" />
                      <span className="text-[10px]">Upload</span>
                    </div>
                  )}
                  {uploading && (
                    <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                      <Loader2 className="w-5 h-5 animate-spin text-white" />
                    </div>
                  )}
                </div>
                <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={handleUpload} />
                {form.avatar_url && (
                  <button onClick={() => setForm((f) => ({ ...f, avatar_url: "" }))} className="text-xs text-muted-foreground hover:text-destructive transition-colors">
                    Remove photo
                  </button>
                )}
              </div>

              {/* Name */}
              <div>
                <label className="text-xs text-muted-foreground uppercase tracking-wider mb-1 block">Name</label>
                <input
                  value={form.name}
                  onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
                  onKeyDown={(e) => e.key === "Enter" && handleSave()}
                  placeholder="Profile name"
                  autoFocus
                  className="w-full px-4 py-2.5 rounded-lg bg-secondary border border-border text-sm focus:outline-none focus:border-primary transition-colors"
                />
              </div>

              {/* Color */}
              {!form.avatar_url && (
                <div>
                  <label className="text-xs text-muted-foreground uppercase tracking-wider mb-2 block">Color</label>
                  <div className="flex gap-2 flex-wrap">
                    {COLORS.map((c) => (
                      <button
                        key={c}
                        onClick={() => setForm((f) => ({ ...f, color: c }))}
                        className="w-8 h-8 rounded-full transition-transform hover:scale-110 border-2"
                        style={{ background: c, borderColor: form.color === c ? "white" : "transparent" }}
                      />
                    ))}
                  </div>
                </div>
              )}

              {/* Actions */}
              <div className="flex gap-3 pt-1">
                {modal !== "new" && (
                  <button
                    onClick={handleDelete}
                    disabled={saving}
                    className="w-10 h-10 rounded-lg bg-destructive/10 border border-destructive/20 text-destructive flex items-center justify-center hover:bg-destructive/20 transition-colors disabled:opacity-50"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
                <button
                  onClick={closeModal}
                  disabled={saving}
                  className="flex-1 py-2.5 rounded-lg bg-secondary border border-border text-sm font-medium hover:bg-secondary/80 transition-colors disabled:opacity-50"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSave}
                  disabled={saving || uploading || !form.name.trim()}
                  className="flex-1 py-2.5 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
                  Save
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}