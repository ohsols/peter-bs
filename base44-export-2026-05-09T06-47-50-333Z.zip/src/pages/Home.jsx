import { useState, useEffect, useMemo } from "react";
import { useOutletContext } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Loader2, Plus } from "lucide-react";
import HeroSection from "../components/HeroSection";
import MovieRow from "../components/MovieRow";
import TvShowRow from "../components/TvShowRow";
import ArchiveStats from "../components/ArchiveStats";
import ContinueWatchingRow from "../components/ContinueWatchingRow";
import { motion } from "framer-motion";
import { useWatchlist } from "@/hooks/useWatchlist.jsx";

const ALL_GENRES = ["All", "Action", "Comedy", "Drama", "Horror", "Sci-Fi", "Thriller", "Romance", "Documentary", "Animation", "Fantasy", "Mystery", "Adventure"];

export default function Home() {
  const { onAddMovie, refreshKey } = useOutletContext();
  const [movies, setMovies] = useState([]);
  const [shows, setShows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedGenre, setSelectedGenre] = useState("All");

  useEffect(() => {
    loadMovies();
  }, [refreshKey]);

  const loadMovies = async () => {
    setLoading(true);
    const [movieData, showData] = await Promise.all([
      base44.entities.Movie.list("-created_date", 100),
      base44.entities.TvShow.list("-created_date", 100)
    ]);
    setMovies(movieData);
    setShows(showData);
    setLoading(false);
  };

  const { watchlist } = useWatchlist();

  const featuredMovie = movies.find((m) => m.is_featured) || movies[0];

  // Get genres from watchlist items, then find matching movies/shows not already in watchlist
  const recommendedMovies = useMemo(() => {
    const watchlistIds = new Set(watchlist.map((w) => w.item_id));
    const watchlistGenres = new Set(
      watchlist
        .map((w) => {
          const movie = movies.find((m) => m.id === w.item_id);
          const show = shows.find((s) => s.id === w.item_id);
          return (movie || show)?.genre;
        })
        .filter(Boolean)
    );
    if (watchlistGenres.size === 0) return [];
    return [
      ...movies.filter((m) => watchlistGenres.has(m.genre) && !watchlistIds.has(m.id)),
      ...shows.filter((s) => watchlistGenres.has(s.genre) && !watchlistIds.has(s.id)),
    ].slice(0, 20);
  }, [watchlist, movies, shows]);

  const filteredMovies = selectedGenre === "All" ? movies : movies.filter((m) => m.genre === selectedGenre);

  const genreGroups = filteredMovies.reduce((acc, movie) => {
    const genre = movie.genre || "Uncategorized";
    if (!acc[genre]) acc[genre] = [];
    acc[genre].push(movie);
    return acc;
  }, {});

  const recentMovies = selectedGenre === "All" ? [...filteredMovies].slice(0, 20) : [];

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-6 h-6 animate-spin text-primary" />
      </div>
    );
  }

  if (movies.length === 0) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center max-w-md"
        >
          <div className="w-20 h-20 rounded-2xl bg-primary/10 border border-primary/20 flex items-center justify-center mx-auto mb-6">
            <Plus className="w-8 h-8 text-primary" />
          </div>
          <h2 className="text-3xl font-black tracking-tight mb-3">Your Archive Awaits</h2>
          <p className="text-muted-foreground mb-8">
            Start building your personal cinema collection. Add your first film with a Google Drive link.
          </p>
          <button
            onClick={onAddMovie}
            className="px-8 py-4 bg-primary text-primary-foreground rounded-lg font-semibold hover:bg-primary/90 transition-all hover:scale-105 active:scale-95"
          >
            Add Your First Film
          </button>
        </motion.div>
      </div>
    );
  }

  return (
    <div>
      <HeroSection featuredMovie={featuredMovie} />

      <ContinueWatchingRow />

      <div className="mt-2 space-y-1">
        {recommendedMovies.length > 0 && (
          <MovieRow title="✦ Recommended for You" movies={recommendedMovies.filter(r => r.drive_link)} />
        )}

        {recentMovies.length > 0 && (
          <MovieRow title="Recently Added" movies={recentMovies} />
        )}

        {Object.entries(genreGroups)
          .filter(([genre]) => genre !== "Uncategorized")
          .map(([genre, genreMovies]) => (
            <MovieRow key={genre} title={genre} movies={genreMovies} />
          ))}

        {genreGroups["Uncategorized"]?.length > 0 && (
          <MovieRow title="Uncategorized" movies={genreGroups["Uncategorized"]} />
        )}

        {shows.length > 0 && (
          <TvShowRow title="TV Shows" shows={shows} />
        )}
      </div>

      <ArchiveStats movies={movies} />
    </div>
  );
}