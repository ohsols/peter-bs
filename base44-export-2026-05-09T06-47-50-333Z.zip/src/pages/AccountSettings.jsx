import { useState, useEffect, useRef } from "react";
import { useNavigate, Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { motion } from "framer-motion";
import { ArrowLeft, Check, Loader2, Upload, User, Palette, LogOut, ChevronRight } from "lucide-react";
import { useProfile } from "@/hooks/useProfile";
import { useAuth } from "@/lib/AuthContext";

const COLORS = ["#e53e3e", "#dd6b20", "#d69e2e", "#38a169", "#3182ce", "#805ad5", "#d53f8c", "#319795"];

export default function AccountSettings() {
  const navigate = useNavigate();
  const { logout } = useAuth();
  const { activeProfile, selectProfile, clearProfile } = useProfile();

  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [uploadingAvatar, setUploadingAvatar] = useState(false);



  // Active profile customization
  const [profileName, setProfileName] = useState("");
  const [profileColor, setProfileColor] = useState(COLORS[0]);
  const [profileAvatar, setProfileAvatar] = useState("");

  const fileRef = useRef();

  useEffect(() => {
    loadUser();
  }, []);

  useEffect(() => {
    if (activeProfile) {
      setProfileName(activeProfile.name || "");
      setProfileColor(activeProfile.color || COLORS[0]);
      setProfileAvatar(activeProfile.avatar_url || "");
    }
  }, [activeProfile]);

  const loadUser = async () => {
    try {
      const me = await base44.auth.me();
      setUser(me);

    } catch (e) {
      console.error("Failed to load user", e);
    } finally {
      setLoading(false);
    }
  };

  const handleAvatarUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setUploadingAvatar(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setProfileAvatar(file_url);
    } finally {
      setUploadingAvatar(false);
      e.target.value = "";
    }
  };

  const handleSave = async () => {
    if (!activeProfile) return;
    setSaving(true);
    const payload = {
      name: profileName.trim() || activeProfile.name,
      color: profileColor,
      avatar_url: profileAvatar,
      user_email: activeProfile.user_email,
    };
    const updated = await base44.entities.Profile.update(activeProfile.id, payload);
    selectProfile(updated);
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="w-6 h-6 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pt-24 pb-16 px-6">
      <div className="max-w-xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-4 mb-10">
          <button
            onClick={() => navigate(-1)}
            className="w-9 h-9 rounded-lg bg-secondary border border-border flex items-center justify-center hover:bg-secondary/80 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <h1 className="text-2xl font-black tracking-tight">Account Settings</h1>
            <p className="text-sm text-muted-foreground">{user?.email}</p>
          </div>
        </div>

        <div className="space-y-6">
          {/* Account Info */}
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} className="bg-card border border-border rounded-2xl p-6 space-y-5">
            <div className="flex items-center gap-2 mb-1">
              <User className="w-4 h-4 text-primary" />
              <h2 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground">Account</h2>
            </div>

            <div>
              <label className="text-xs text-muted-foreground uppercase tracking-wider mb-1.5 block">Display Name</label>
              <input
                value={user?.full_name || ""}
                disabled
                className="w-full px-4 py-2.5 rounded-lg bg-secondary/50 border border-border text-sm text-muted-foreground cursor-not-allowed"
              />
            </div>

            <div>
              <label className="text-xs text-muted-foreground uppercase tracking-wider mb-1.5 block">Email</label>
              <input
                value={user?.email || ""}
                disabled
                className="w-full px-4 py-2.5 rounded-lg bg-secondary/50 border border-border text-sm text-muted-foreground cursor-not-allowed"
              />
            </div>
          </motion.div>

          {/* Active Profile Customization */}
          {activeProfile ? (
            <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }} className="bg-card border border-border rounded-2xl p-6 space-y-5">
              <div className="flex items-center gap-2 mb-1">
                <Palette className="w-4 h-4 text-primary" />
                <h2 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground">Active Profile — {activeProfile.name}</h2>
              </div>

              {/* Avatar */}
              <div className="flex items-center gap-5">
                <div
                  className="relative w-20 h-20 rounded-xl overflow-hidden cursor-pointer border-2 border-border hover:border-primary transition-colors flex-shrink-0"
                  style={{ background: profileAvatar ? undefined : profileColor }}
                  onClick={() => fileRef.current?.click()}
                >
                  {profileAvatar ? (
                    <img src={profileAvatar} alt="avatar" className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-3xl font-black text-white/80">
                      {profileName.charAt(0).toUpperCase() || "?"}
                    </div>
                  )}
                  {uploadingAvatar && (
                    <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                      <Loader2 className="w-5 h-5 animate-spin text-white" />
                    </div>
                  )}
                  <div className="absolute inset-0 bg-black/0 hover:bg-black/30 flex items-center justify-center transition-colors group">
                    <Upload className="w-5 h-5 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium mb-1">Profile Photo</p>
                  <p className="text-xs text-muted-foreground mb-3">Click the avatar to upload a photo, or pick a color below.</p>
                  {profileAvatar && (
                    <button onClick={() => setProfileAvatar("")} className="text-xs text-destructive hover:underline">
                      Remove photo
                    </button>
                  )}
                </div>
              </div>
              <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={handleAvatarUpload} />

              {/* Profile Name */}
              <div>
                <label className="text-xs text-muted-foreground uppercase tracking-wider mb-1.5 block">Profile Name</label>
                <input
                  value={profileName}
                  onChange={(e) => setProfileName(e.target.value)}
                  placeholder="Profile name"
                  className="w-full px-4 py-2.5 rounded-lg bg-secondary border border-border text-sm focus:outline-none focus:border-primary transition-colors"
                />
              </div>

              {/* Color */}
              {!profileAvatar && (
                <div>
                  <label className="text-xs text-muted-foreground uppercase tracking-wider mb-2 block">Profile Color</label>
                  <div className="flex gap-2.5 flex-wrap">
                    {COLORS.map((c) => (
                      <button
                        key={c}
                        onClick={() => setProfileColor(c)}
                        className="w-9 h-9 rounded-full transition-transform hover:scale-110 border-2 flex items-center justify-center"
                        style={{ background: c, borderColor: profileColor === c ? "white" : "transparent" }}
                      >
                        {profileColor === c && <Check className="w-4 h-4 text-white" />}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </motion.div>
          ) : (
            <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }} className="bg-card border border-border rounded-2xl p-6">
              <p className="text-sm text-muted-foreground mb-4">No active profile selected. Select a profile first to customize it.</p>
              <Link to="/profiles" className="flex items-center gap-2 text-sm text-primary hover:underline font-medium">
                Go to Profiles <ChevronRight className="w-4 h-4" />
              </Link>
            </motion.div>
          )}

          {/* Manage Profiles */}
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
            <Link
              to="/profiles"
              className="flex items-center justify-between w-full bg-card border border-border rounded-2xl p-5 hover:border-primary/40 transition-colors group"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-lg bg-secondary flex items-center justify-center">
                  <User className="w-4 h-4 text-muted-foreground" />
                </div>
                <div>
                  <p className="text-sm font-semibold">Manage Profiles</p>
                  <p className="text-xs text-muted-foreground">Add, edit or delete profiles</p>
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-muted-foreground group-hover:text-foreground transition-colors" />
            </Link>
          </motion.div>

          {/* Save Button */}
          <button
            onClick={handleSave}
            disabled={saving || uploadingAvatar}
            className="w-full py-3.5 rounded-xl bg-primary text-primary-foreground font-semibold text-sm hover:bg-primary/90 transition-all disabled:opacity-50 flex items-center justify-center gap-2"
          >
            {saving ? (
              <><Loader2 className="w-4 h-4 animate-spin" /> Saving…</>
            ) : saved ? (
              <><Check className="w-4 h-4" /> Saved!</>
            ) : (
              "Save Changes"
            )}
          </button>

          {/* Sign Out */}
          <button
            onClick={() => logout()}
            className="w-full py-3 rounded-xl bg-transparent border border-border text-muted-foreground text-sm font-medium hover:bg-destructive/10 hover:text-destructive hover:border-destructive/30 transition-all flex items-center justify-center gap-2"
          >
            <LogOut className="w-4 h-4" />
            Sign Out
          </button>
        </div>
      </div>
    </div>
  );
}