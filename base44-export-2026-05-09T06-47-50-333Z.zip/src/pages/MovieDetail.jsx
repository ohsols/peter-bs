import { useState, useEffect } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { motion } from "framer-motion";
import { Play, ArrowLeft, ExternalLink, Calendar, Clock, User, Film, Trash2, Loader2, X, Bookmark, Users } from "lucide-react";
import ActorModal from "@/components/ActorModal";
import { toast } from "@/components/ui/use-toast";
import { useWatchlist } from "@/hooks/useWatchlist.jsx";
import { useWatchTracking } from "@/hooks/useWatchTracking";
import StarRating from "@/components/StarRating";
import { useAuth } from "@/lib/AuthContext";

export default function MovieDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { isInWatchlist, toggle } = useWatchlist();
  const { markWatching } = useWatchTracking();
  const { user } = useAuth();
  const isAdmin = user?.role === "admin";
  const [movie, setMovie] = useState(null);
  const [loading, setLoading] = useState(true);
  const [deleting, setDeleting] = useState(false);
  const [playing, setPlaying] = useState(false);
  const [selectedActor, setSelectedActor] = useState(null);

  useEffect(() => {
    loadMovie();
  }, [id]);

  const loadMovie = async () => {
    setLoading(true);
    const data = await base44.entities.Movie.filter({ id });
    if (data.length > 0) {
      setMovie(data[0]);
    }
    setLoading(false);
  };

  const handleDelete = async () => {
    if (!confirm("Remove this film from your archive?")) return;
    setDeleting(true);
    await base44.entities.Movie.delete(movie.id);
    toast({ title: "Film removed", description: `"${movie.title}" has been removed from your archive.` });
    navigate("/");
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-6 h-6 animate-spin text-primary" />
      </div>
    );
  }

  if (!movie) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center">
        <p className="text-muted-foreground mb-4">Film not found</p>
        <Link to="/" className="text-primary hover:underline">Return to archive</Link>
      </div>
    );
  }

  const getEmbedUrl = (url) => {
    if (!url) return null;
    const match = url.match(/\/d\/([a-zA-Z0-9_-]+)/);
    if (match) return `https://drive.google.com/file/d/${match[1]}/preview`;
    return url;
  };

  const metaItems = [
    { label: "Year", value: movie.year, icon: Calendar },
    { label: "Runtime", value: movie.runtime, icon: Clock },
    { label: "Director", value: movie.director, icon: User },
    { label: "Genre", value: movie.genre, icon: Film },
  ].filter((item) => item.value);

  return (
    <div className="min-h-screen pt-20">
      {/* Back button */}
      <div className="max-w-[1600px] mx-auto px-6 md:px-12 py-6">
        <button
          onClick={() => navigate(-1)}
          className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back
        </button>
      </div>

      <div className="max-w-[1600px] mx-auto px-6 md:px-12">
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-12">
          {/* Left - Metadata */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            className="lg:col-span-2 space-y-8"
          >
            {movie.genre && (
              <span className="inline-block px-3 py-1 text-xs font-semibold tracking-widest uppercase bg-primary/10 text-primary rounded-full border border-primary/20">
                {movie.genre}
              </span>
            )}

            <h1 className="text-4xl md:text-6xl font-black tracking-tighter leading-[0.95]">
              {movie.title}
            </h1>

            {movie.description && (
              <p className="text-lg text-muted-foreground leading-relaxed">
                {movie.description}
              </p>
            )}

            <StarRating item={{ ...movie, item_type: "movie" }} />

            {/* Meta table */}
            {metaItems.length > 0 && (
              <div className="border-t border-border pt-6 space-y-4">
                {metaItems.map((item) => (
                  <div key={item.label} className="flex items-center gap-4">
                    <div className="w-8 h-8 rounded-md bg-secondary flex items-center justify-center">
                      <item.icon className="w-3.5 h-3.5 text-muted-foreground" />
                    </div>
                    <div>
                      <div className="text-xs text-muted-foreground uppercase tracking-wider">{item.label}</div>
                      <div className="text-sm font-medium">{item.value}</div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Cast */}
            {movie.cast && movie.cast.length > 0 && (
              <div className="border-t border-border pt-6">
                <h3 className="flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-muted-foreground mb-3">
                  <Users className="w-3.5 h-3.5" /> Cast
                </h3>
                <div className="flex flex-wrap gap-2">
                  {movie.cast.map((actor) => (
                    <button
                      key={actor}
                      onClick={() => setSelectedActor(actor)}
                      className="px-3 py-1.5 text-xs font-medium bg-secondary hover:bg-primary/10 hover:text-primary border border-border hover:border-primary/30 rounded-full transition-all"
                    >
                      {actor}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Actions */}
            <div className="flex flex-col gap-3 pt-4">
              <button
                onClick={() => { setPlaying(true); markWatching({ id: movie.id, item_type: "movie", title: movie.title, poster_url: movie.poster_url }); }}
                className="flex items-center justify-center gap-3 px-8 py-4 bg-primary text-primary-foreground rounded-lg font-semibold hover:bg-primary/90 transition-all hover:scale-[1.02] active:scale-[0.98]"
              >
                <Play className="w-5 h-5 fill-current" />
                Play on Site
              </button>
              <a
                href={movie.drive_link}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 px-6 py-3 bg-secondary text-foreground rounded-lg font-medium hover:bg-secondary/80 transition-all border border-border text-sm"
              >
                <ExternalLink className="w-4 h-4" />
                Open in Google Drive
              </a>
              <button
                onClick={() => toggle({ ...movie, item_type: "movie" })}
                className={`flex items-center justify-center gap-2 px-6 py-3 rounded-lg font-medium transition-all border text-sm ${isInWatchlist(movie.id) ? "bg-primary/10 border-primary/30 text-primary" : "bg-secondary border-border text-foreground hover:bg-secondary/80"}`}
              >
                <Bookmark className={`w-4 h-4 ${isInWatchlist(movie.id) ? "fill-current" : ""}`} />
                {isInWatchlist(movie.id) ? "Saved to Watch Later" : "Watch Later"}
              </button>
              {isAdmin && (
                <button
                  onClick={handleDelete}
                  disabled={deleting}
                  className="flex items-center justify-center gap-2 px-6 py-3 text-destructive hover:bg-destructive/10 rounded-lg font-medium transition-all text-sm"
                >
                  {deleting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
                  Remove from Archive
                </button>
              )}
            </div>
          </motion.div>

          {/* Right - Poster / Player */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="lg:col-span-3"
          >
            <div className="relative aspect-[16/10] rounded-2xl overflow-hidden bg-secondary">
              {playing ? (
                <>
                  <iframe
                    src={getEmbedUrl(movie.drive_link)}
                    className="w-full h-full"
                    allow="autoplay"
                    allowFullScreen
                  />
                  <button
                    onClick={() => setPlaying(false)}
                    className="absolute top-3 right-3 w-8 h-8 rounded-full bg-background/80 backdrop-blur-sm flex items-center justify-center hover:bg-background transition-colors z-10"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </>
              ) : (
                <>
                  {movie.poster_url ? (
                    <img src={movie.poster_url} alt={movie.title} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-secondary to-card">
                      <span className="text-[200px] font-black text-muted-foreground/5 tracking-tighter leading-none">
                        {movie.title?.charAt(0)}
                      </span>
                    </div>
                  )}
                  <button
                    onClick={() => setPlaying(true)}
                    className="absolute inset-0 flex items-center justify-center bg-background/20 opacity-0 hover:opacity-100 transition-opacity group"
                  >
                    <div className="w-16 h-16 rounded-full bg-primary/90 flex items-center justify-center group-hover:scale-110 transition-transform">
                      <Play className="w-7 h-7 text-primary-foreground fill-current ml-1" />
                    </div>
                  </button>
                  {/* Light leak */}
                  <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-transparent pointer-events-none" />
                </>
              )}
            </div>


          </motion.div>
        </div>
      </div>

      <div className="h-32" />

      {selectedActor && (
        <ActorModal actorName={selectedActor} onClose={() => setSelectedActor(null)} />
      )}
    </div>
  );
}