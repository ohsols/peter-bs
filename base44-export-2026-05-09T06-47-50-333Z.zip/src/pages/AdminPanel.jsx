import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { motion } from "framer-motion";
import { Film, Tv, Pencil, Trash2, Loader2, Plus, ArrowLeft, Save, X, Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { toast } from "@/components/ui/use-toast";
import AddMovieModal from "@/components/AddMovieModal";

const GENRES = ["Action","Comedy","Drama","Horror","Sci-Fi","Thriller","Romance","Documentary","Animation","Fantasy","Mystery","Adventure","Anime"];

function EditMovieModal({ movie, onClose, onSaved }) {
  const [form, setForm] = useState({ ...movie });
  const [saving, setSaving] = useState(false);

  const save = async () => {
    setSaving(true);
    await base44.entities.Movie.update(movie.id, form);
    toast({ title: "Film updated" });
    onSaved({ ...movie, ...form });
    onClose();
    setSaving(false);
  };

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-6" onClick={onClose}>
      <div className="bg-card border border-border rounded-2xl p-8 w-full max-w-lg space-y-4" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-2">
          <h2 className="text-xl font-bold">Edit Film</h2>
          <button onClick={onClose}><X className="w-5 h-5 text-muted-foreground hover:text-foreground" /></button>
        </div>
        {[
          { label: "Title", key: "title" },
          { label: "Description", key: "description", textarea: true },
          { label: "Year", key: "year", type: "number" },
          { label: "Director", key: "director" },
          { label: "Runtime", key: "runtime" },
          { label: "Poster URL", key: "poster_url" },
          { label: "Drive Link", key: "drive_link" },
        ].map(({ label, key, textarea, type }) => (
          <div key={key}>
            <label className="text-xs text-muted-foreground uppercase tracking-wider mb-1 block">{label}</label>
            {textarea ? (
              <textarea
                value={form[key] || ""}
                onChange={e => setForm(f => ({ ...f, [key]: e.target.value }))}
                className="w-full px-3 py-2 rounded-lg bg-secondary border border-border text-sm focus:outline-none focus:border-primary resize-none h-20"
              />
            ) : (
              <Input
                type={type || "text"}
                value={form[key] || ""}
                onChange={e => setForm(f => ({ ...f, [key]: type === "number" ? Number(e.target.value) : e.target.value }))}
                className="bg-secondary border-border"
              />
            )}
          </div>
        ))}
        <div>
          <label className="text-xs text-muted-foreground uppercase tracking-wider mb-1 block">Genre</label>
          <select value={form.genre || ""} onChange={e => setForm(f => ({ ...f, genre: e.target.value }))} className="w-full px-3 py-2 rounded-lg bg-secondary border border-border text-sm focus:outline-none focus:border-primary">
            <option value="">— None —</option>
            {GENRES.map(g => <option key={g} value={g}>{g}</option>)}
          </select>
        </div>
        <div className="flex gap-3 pt-2">
          <button onClick={onClose} className="flex-1 py-2.5 rounded-lg bg-secondary border border-border text-sm hover:bg-secondary/80">Cancel</button>
          <button onClick={save} disabled={saving} className="flex-1 py-2.5 rounded-lg bg-primary text-primary-foreground text-sm font-semibold hover:bg-primary/90 flex items-center justify-center gap-2 disabled:opacity-50">
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            Save
          </button>
        </div>
      </div>
    </div>
  );
}

function EditShowModal({ show, onClose, onSaved }) {
  const [form, setForm] = useState({ ...show });
  const [saving, setSaving] = useState(false);

  const save = async () => {
    setSaving(true);
    await base44.entities.TvShow.update(show.id, form);
    toast({ title: "Show updated" });
    onSaved({ ...show, ...form });
    onClose();
    setSaving(false);
  };

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-6" onClick={onClose}>
      <div className="bg-card border border-border rounded-2xl p-8 w-full max-w-lg space-y-4" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-2">
          <h2 className="text-xl font-bold">Edit Show</h2>
          <button onClick={onClose}><X className="w-5 h-5 text-muted-foreground hover:text-foreground" /></button>
        </div>
        {[
          { label: "Title", key: "title" },
          { label: "Description", key: "description", textarea: true },
          { label: "Year", key: "year", type: "number" },
          { label: "Poster URL", key: "poster_url" },
        ].map(({ label, key, textarea, type }) => (
          <div key={key}>
            <label className="text-xs text-muted-foreground uppercase tracking-wider mb-1 block">{label}</label>
            {textarea ? (
              <textarea
                value={form[key] || ""}
                onChange={e => setForm(f => ({ ...f, [key]: e.target.value }))}
                className="w-full px-3 py-2 rounded-lg bg-secondary border border-border text-sm focus:outline-none focus:border-primary resize-none h-20"
              />
            ) : (
              <Input
                type={type || "text"}
                value={form[key] || ""}
                onChange={e => setForm(f => ({ ...f, [key]: type === "number" ? Number(e.target.value) : e.target.value }))}
                className="bg-secondary border-border"
              />
            )}
          </div>
        ))}
        <div>
          <label className="text-xs text-muted-foreground uppercase tracking-wider mb-1 block">Genre</label>
          <select value={form.genre || ""} onChange={e => setForm(f => ({ ...f, genre: e.target.value }))} className="w-full px-3 py-2 rounded-lg bg-secondary border border-border text-sm focus:outline-none focus:border-primary">
            <option value="">— None —</option>
            {GENRES.map(g => <option key={g} value={g}>{g}</option>)}
          </select>
        </div>
        <div className="flex gap-3 pt-2">
          <button onClick={onClose} className="flex-1 py-2.5 rounded-lg bg-secondary border border-border text-sm hover:bg-secondary/80">Cancel</button>
          <button onClick={save} disabled={saving} className="flex-1 py-2.5 rounded-lg bg-primary text-primary-foreground text-sm font-semibold hover:bg-primary/90 flex items-center justify-center gap-2 disabled:opacity-50">
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            Save
          </button>
        </div>
      </div>
    </div>
  );
}

export default function AdminPanel() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const isAdmin = user?.role === "admin";

  const [movies, setMovies] = useState([]);
  const [shows, setShows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState("movies");
  const [search, setSearch] = useState("");
  const [editMovie, setEditMovie] = useState(null);
  const [editShow, setEditShow] = useState(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [deletingId, setDeletingId] = useState(null);

  useEffect(() => {
    if (!isAdmin) return;
    loadData();
  }, [isAdmin]);

  const loadData = async () => {
    setLoading(true);
    const [m, s] = await Promise.all([
      base44.entities.Movie.list("-created_date", 500),
      base44.entities.TvShow.list("-created_date", 500),
    ]);
    setMovies(m);
    setShows(s);
    setLoading(false);
  };

  const deleteMovie = async (movie) => {
    if (!confirm(`Remove "${movie.title}"?`)) return;
    setDeletingId(movie.id);
    await base44.entities.Movie.delete(movie.id);
    setMovies(prev => prev.filter(m => m.id !== movie.id));
    setDeletingId(null);
    toast({ title: "Film removed" });
  };

  const deleteShow = async (show) => {
    if (!confirm(`Delete "${show.title}" and all its episodes?`)) return;
    setDeletingId(show.id);
    const eps = await base44.entities.Episode.filter({ show_id: show.id });
    await Promise.all([
      base44.entities.TvShow.delete(show.id),
      ...eps.map(ep => base44.entities.Episode.delete(ep.id))
    ]);
    setShows(prev => prev.filter(s => s.id !== show.id));
    setDeletingId(null);
    toast({ title: "Show deleted" });
  };

  if (!isAdmin) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-background">
        <p className="text-muted-foreground text-lg">Access denied.</p>
        <button onClick={() => navigate("/")} className="mt-4 text-primary hover:underline text-sm">Go home</button>
      </div>
    );
  }

  const filteredMovies = movies.filter(m => m.title?.toLowerCase().includes(search.toLowerCase()));
  const filteredShows = shows.filter(s => s.title?.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="min-h-screen bg-background pt-10 pb-20">
      <div className="max-w-[1400px] mx-auto px-6 md:px-12">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <button onClick={() => navigate("/")} className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors">
            <ArrowLeft className="w-4 h-4" /> Back
          </button>
          <div>
            <h1 className="text-3xl font-black tracking-tighter">Admin Panel</h1>
            <p className="text-sm text-muted-foreground mt-0.5">Manage the film library and TV shows</p>
          </div>
          <button
            onClick={() => setShowAddModal(true)}
            className="ml-auto flex items-center gap-2 px-5 py-2.5 bg-primary text-primary-foreground rounded-lg text-sm font-semibold hover:bg-primary/90 transition-all"
          >
            <Plus className="w-4 h-4" /> Add Film
          </button>
        </div>

        {/* Tabs + Search */}
        <div className="flex flex-col sm:flex-row sm:items-center gap-4 mb-6">
          <div className="flex items-center gap-1 border-b border-border">
            <button
              onClick={() => setTab("movies")}
              className={`flex items-center gap-2 px-5 py-3 text-sm font-semibold border-b-2 transition-colors -mb-px ${tab === "movies" ? "border-primary text-foreground" : "border-transparent text-muted-foreground hover:text-foreground"}`}
            >
              <Film className="w-4 h-4" /> Films ({movies.length})
            </button>
            <button
              onClick={() => setTab("shows")}
              className={`flex items-center gap-2 px-5 py-3 text-sm font-semibold border-b-2 transition-colors -mb-px ${tab === "shows" ? "border-primary text-foreground" : "border-transparent text-muted-foreground hover:text-foreground"}`}
            >
              <Tv className="w-4 h-4" /> TV Shows ({shows.length})
            </button>
          </div>
          <div className="relative sm:ml-auto max-w-xs w-full">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search..." className="pl-9 bg-card border-border" />
          </div>
        </div>

        {/* Content */}
        {loading ? (
          <div className="flex items-center justify-center py-24">
            <Loader2 className="w-6 h-6 animate-spin text-primary" />
          </div>
        ) : tab === "movies" ? (
          <div className="space-y-2">
            {filteredMovies.map((movie, i) => (
              <motion.div
                key={movie.id}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.02 }}
                className="flex items-center gap-4 px-5 py-4 bg-card rounded-xl border border-border hover:border-border/80 group"
              >
                <div className="w-10 h-14 rounded-md overflow-hidden bg-secondary flex-shrink-0">
                  {movie.poster_url ? (
                    <img src={movie.poster_url} alt="" className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-muted-foreground/30 font-bold text-lg">{movie.title?.charAt(0)}</div>
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold truncate">{movie.title}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">{[movie.year, movie.genre, movie.director].filter(Boolean).join(" · ")}</p>
                </div>
                <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button
                    onClick={() => setEditMovie(movie)}
                    className="w-8 h-8 rounded-lg bg-secondary border border-border flex items-center justify-center hover:border-primary/40 hover:text-primary transition-colors"
                  >
                    <Pencil className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => deleteMovie(movie)}
                    disabled={deletingId === movie.id}
                    className="w-8 h-8 rounded-lg bg-destructive/10 border border-destructive/20 text-destructive flex items-center justify-center hover:bg-destructive/20 transition-colors disabled:opacity-50"
                  >
                    {deletingId === movie.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Trash2 className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </motion.div>
            ))}
            {filteredMovies.length === 0 && <p className="text-center py-12 text-muted-foreground">No films found.</p>}
          </div>
        ) : (
          <div className="space-y-2">
            {filteredShows.map((show, i) => (
              <motion.div
                key={show.id}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.02 }}
                className="flex items-center gap-4 px-5 py-4 bg-card rounded-xl border border-border hover:border-border/80 group"
              >
                <div className="w-10 h-14 rounded-md overflow-hidden bg-secondary flex-shrink-0">
                  {show.poster_url ? (
                    <img src={show.poster_url} alt="" className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-muted-foreground/30 font-bold text-lg">{show.title?.charAt(0)}</div>
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold truncate">{show.title}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">{[show.year, show.genre].filter(Boolean).join(" · ")}</p>
                </div>
                <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button
                    onClick={() => setEditShow(show)}
                    className="w-8 h-8 rounded-lg bg-secondary border border-border flex items-center justify-center hover:border-primary/40 hover:text-primary transition-colors"
                  >
                    <Pencil className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => deleteShow(show)}
                    disabled={deletingId === show.id}
                    className="w-8 h-8 rounded-lg bg-destructive/10 border border-destructive/20 text-destructive flex items-center justify-center hover:bg-destructive/20 transition-colors disabled:opacity-50"
                  >
                    {deletingId === show.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Trash2 className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </motion.div>
            ))}
            {filteredShows.length === 0 && <p className="text-center py-12 text-muted-foreground">No shows found.</p>}
          </div>
        )}
      </div>

      {editMovie && (
        <EditMovieModal
          movie={editMovie}
          onClose={() => setEditMovie(null)}
          onSaved={updated => setMovies(prev => prev.map(m => m.id === updated.id ? updated : m))}
        />
      )}
      {editShow && (
        <EditShowModal
          show={editShow}
          onClose={() => setEditShow(null)}
          onSaved={updated => setShows(prev => prev.map(s => s.id === updated.id ? updated : s))}
        />
      )}
      {showAddModal && (
        <AddMovieModal
          open={showAddModal}
          onClose={() => setShowAddModal(false)}
          onMovieAdded={() => { loadData(); setShowAddModal(false); }}
        />
      )}
    </div>
  );
}